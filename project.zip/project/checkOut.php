<?php
include "php/lib/appSession.php";
Session ::checkappSession();
include "php/config/config.php";
include "php/lib/DB.php";
include "php/lib/helpers.php";
include "php/classes/appointmentFunction.php";
$db          = new DataBase();
$help        = new Helpers();
$appFunction = new appointmentFunctiuon();


if(isset($_GET['checkOut'])){
	$chekOut = $_GET['checkOut'];
}
$checkOut = $appFunction->checkOutStart($chekOut);

?>