
				<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav side-nav">
						<li>
							<a href="#" data-toggle="collapse" data-target="#submenu-1">
								<i class="fas fa-users"></i> &nbsp; Manage Visitor <i class="fa fa-fw fa-angle-down pull-right"></i></a>
							<ul id="submenu-1" class="collapse">
								<li><a href="visitedVDetails.php"><i class="fa fa-angle-double-right"></i> Visited Visitor List</a></li>
								<li><a href="nVisitedVDetails.php"><i class="fa fa-angle-double-right"></i> Not Visited Visitor List</a></li>
								
							</ul>
						</li>
						<li>
							<a href="#" data-toggle="collapse" data-target="#submenu-2"><i class="fas fa-registered"></i>  &nbsp; Registered Visitor <i class="fa fa-fw fa-angle-down pull-right"></i></a>
							<ul id="submenu-2" class="collapse">
								<li><a href="regVisitor.php"><i class="fa fa-angle-double-right"></i> Registered Visitor</a></li>
								<li title="Deleted Registered Visitor"><a href="deletedVisitor.php"><i class="fa fa-angle-double-right"></i> Deleted Visitor</a></li>
								
							</ul>
						</li>
						<li>
							<a href="#" data-toggle="collapse" data-target="#submenu-3"><i class="fab fa-typo3"></i>  &nbsp; Manage Visitor Type <i class="fa fa-fw fa-angle-down pull-right"></i></a>
							<ul id="submenu-3" class="collapse">
								<li><a href="addVisitorType.php"><i class="fa fa-angle-double-right"></i> Add Visitor Type</a></li>
								<li><a href="visitorType.php"><i class="fa fa-angle-double-right"></i> Visitor Type Details</a></li>
								
							</ul>
						</li>
						
						
						<li>
							<a href="#" data-toggle="collapse" data-target="#submenu-4"><i class="fas fa-user"></i>  &nbsp; Manage Employ <i class="fa fa-fw fa-angle-down pull-right"></i></a>
							<ul id="submenu-4" class="collapse">
								<li><a href="addEmploy.php"><i class="fa fa-angle-double-right"></i> Add Employ</a></li>
								<li><a href="employList.php"><i class="fa fa-angle-double-right"></i> Employ List</a></li>
								
							</ul>
						</li>
						
						
						
						<li>
							<a href="visitorReport.php"><i class="fab fa-readme"></i>  &nbsp; Visitor Report</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</nav>