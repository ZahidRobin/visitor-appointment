<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-bottom">
   <div class="container">
      <p class="m-0 text-center text-white">All Right Reserved</p>
      <p class="m-0 text-center text-white">Copyright &copy; By Pranto 2018</p>
   </div>
</nav>
</div>
<!-- Bootstrap core JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
</body>
</html>