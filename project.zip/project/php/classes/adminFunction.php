<?php
class adminInfo{
	
	public $db;
	public $help;
	
	public function __construct(){
		
		$this->db   = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function addVisitorType($data){
		
		$visitorType = mysqli_real_escape_string($this->db->link,$data['vType']);
		$visitorType = $this->help->validation($visitorType);
		
		$checkVisitorType = "SELECT `visitortype` FROM `tbl_visitortype` 
		WHERE `visitortype` = '$visitorType'";
		$check  		  = $this->db->select($checkVisitorType);
				
		if(empty($visitorType)){
			$msg = '<div class="form-group">
			<div class="col-sm-12">
			<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error !</strong> Field must not be empty !
			</div>
			</div>
			</div>';
			return $msg;
			
		}elseif($check == TRUE){
			$msg = '<div class="form-group">
			<div class="col-sm-12">
			<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error !</strong> This Visitor type has been already added !
			</div>
			</div>
			</div>';
			return $msg;
		}else{
			
			$insert = "INSERT INTO `tbl_visitortype`(`visitortype`) 
			VALUES ('$visitorType')";
					   
			$sql    = $this->db->insart($insert);
			
			if($sql){
				
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-success alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success ! </strong> <b>' .$visitorType.'</b> Visitor type insarted successfull .
				</div>
				</div>
				</div>';
				return $msg;
				
			}else{
				
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Visitor type not insarted successfull !
				</div>
				</div>
				</div>';
				return $msg;
				
			}
			
		}
		
	}
	
	
	public function addEmploye($data){
		
		$employe   = mysqli_escape_string($this->db->link,$data['employe']);
		$employeId = mysqli_escape_string($this->db->link,$data['employeId']);
		
		$employe   = $this->help->validation($employe);
		$employeId = $this->help->validation($employeId);
		
		$CheckEmployeId = "SELECT `employId` FROM `tbl_employe` WHERE `employId` = '$employeId'";
		$checkId        = $this->db->select($CheckEmployeId);
		
		
		if($employe == "" OR $employeId == ""){
			
			$msg = '<div class="form-group">
			<div class="col-sm-12">
			<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error ! </strong> Field must not be empty !
			</div>
			</div>
			</div>';
			return $msg;
			
		}elseif($checkId == TRUE){
			
			$msg = '<div class="form-group">
			<div class="col-sm-12">
			<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error !</strong> This Employe has been already added !
			</div>
			</div>
			</div>';
			return $msg;
		}else{
			$insert = "INSERT INTO `tbl_employe`(`employName`, `employId`) 
			VALUES ('$employe','$employeId')";
			$sql    = $this->db->insart($insert);
			
			if($sql){
				
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-success alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success ! </strong><b>' .$employe.'</b> Employe insarted successfull .
				</div>
				</div>
				</div>';
				return $msg;
				
			}else{
				
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Employe not insarted successfull !
				</div>
				</div>
				</div>';
				return $msg;
				
			}
		}
	}
	
	
	
	/*End Add Function*/
	
	
	public function getVisitorType(){
		
		$select = "SELECT * FROM `tbl_visitortype` ORDER BY id DESC";
		$sql    = $this->db->select($select);
		
		if($sql){
			while($readVtype = $sql->fetch_assoc()){
				$resultVtype[] = $readVtype;
			}
			
			return $resultVtype ;
		}
		
	}
	
	public function updateVisitorType($data){
		
		$id    = mysqli_escape_string($this->db->link,$data['id']);
		$vType = mysqli_escape_string($this->db->link,$data['vType']);
		
		$id    = $this->help->validation($id);
		$vType = $this->help->validation($vType);
		
		$checkVisitorType = "SELECT `visitortype` FROM `tbl_visitortype` 
		WHERE `visitortype` = '$vType'";
		$check  		  = $this->db->select($checkVisitorType);
		
		
		if($vType == ""){
			
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Field must not be empty !
				</div>
				</div>
				</div>';
			return $msg;
			
		}elseif($check == TRUE){
			
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> This visitor type is already added !
				</div>
				</div>
				</div>';
			return $msg;
			
			
		}else{
			
			$update = "UPDATE `tbl_visitortype` SET `visitortype`='$vType' WHERE `id` = '$id'";
			$sql    = $this->db->update($update);
			
			if($sql){
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-success alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success ! </strong><b>'.$vType.'</b> Visitor Type update successfull .
				</div>
				</div>
				</div>';
				return $msg;
			}else{
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong>Visitor Type not updated .
				</div>
				</div>
				</div>';
				return $msg;
			}
			
		}

	}
	
	public function deleteVisitorType($data){
		
		$id 	= $data['id'];
		
		$delete = "DELETE FROM `tbl_visitortype` WHERE id = '$id'";
		$sql    = $this->db->delete($delete);
		
		if($sql){
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-success alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Success ! </strong> Visitor Type delete successfull .
				</div>
				</div>
				</div>';
				return $msg;
		}else{
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error ! </strong> Visitor Type not deleted .
				</div>
				</div>
				</div>';
				return $msg;
			
			
		}
		
	}
	
	
	public function getEmploye(){
			$select = "SELECT * FROM `tbl_employe` ORDER BY id DESC";
			$sql    = $this->db->select($select);

			if($sql){
				while($readEmploye = $sql->fetch_assoc()){
					$resultEmploye[] = $readEmploye;
				}

				return $resultEmploye ;
			}
									
		}
		
	public function updateEmploye($data){
			
			$id      = mysqli_escape_string($this->db->link,$data['id']);
			$empName = mysqli_escape_string($this->db->link,$data['empName']);
			$empId   = mysqli_escape_string($this->db->link,$data['empId']);
			
			$id      = $this->help->validation($id);
			$empName = $this->help->validation($empName);
			$empId   = $this->help->validation($empId);
			
	$CheckEmployeId = "SELECT `employId` FROM `tbl_employe` WHERE `employId` = '$empId'";
	$checkId        = $this->db->select($CheckEmployeId);
			
			
			
			if($empName == "" OR $empId == ""){
				
				$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Field must not be empty !
					</div>
					</div>
					</div>';
				return $msg;
				
			}elseif($checkId == TRUE){
				
				$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> This Employe Id is already added !
					</div>
					</div>
					</div>';
				return $msg;
				
			}else{
				
				$update = "UPDATE `tbl_employe` SET 
						 `employName` ='$empName',
						 `employId`   ='$empId'
						  WHERE `id`  = '$id'";
				$sql    = $this->db->update($update);
				
				if($sql){
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-success alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Success ! </strong><b>'.$empName.'</b> Visitor Type update successfull .
					</div>
					</div>
					</div>';
					return $msg;
				}else{
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong>Visitor Type not updated .
					</div>
					</div>
					</div>';
					return $msg;
				}
				
			}

		}
		
		public function deleteEmploye($data){
			
			$id 	= $data['id'];
			
			$delete = "DELETE FROM `tbl_employe` WHERE id = '$id'";
			$sql    = $this->db->delete($delete);
			
			if($sql){
				$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-success alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Success ! </strong> Employe delete successfull .
					</div>
					</div>
					</div>';
					return $msg;
			}else{
				$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error ! </strong> Employe not deleted .
					</div>
					</div>
					</div>';
					return $msg;
				
				
			}
			
		}
		
		
		public function currentAppoinment(){
			date_default_timezone_set('Asia/Dhaka');
			$date      = date("Y-m-d");
			$selectApp = "SELECT * FROM `tbl_appointment` WHERE `visitingDate` = '$date'";
			$sqlAPp    = $this->db->select($selectApp);
			
			if($sqlAPp){
				while($readApp   = $sqlAPp->fetch_assoc()){
					$resultApp[] = $readApp; 
				}
				return $resultApp;
			}
			
		}
		
		
		public function getAppDetails($id){
			
			$selectApp = "SELECT * FROM `tbl_appointment` WHERE `id` = '$id' ORDER BY id DESC";
			$sqlAPp    = $this->db->select($selectApp);
			$readApp   = $sqlAPp->fetch_assoc();
			return $readApp;
		}
		
		
		public function visitedVisitor(){
			
			$selectVvisitor = "SELECT * FROM `tbl_appointment` WHERE 
							  `checkIn` != '' AND `checkOut` != '' ORDER BY id DESC";
			$sqlVvisitor    = $this->db->select($selectVvisitor);
			
			if($sqlVvisitor){
				while($readVvis   = $sqlVvisitor->fetch_assoc()){
					$resultVvis[] = $readVvis; 
				}
				return $resultVvis;
			}
			
		}
		
		
		public function notVisitedVisitor(){
			
			$selectnotVvisitor = "SELECT * FROM `tbl_appointment` WHERE 
							  	 `checkIn` = '' AND `checkOut` = '' ORDER BY id DESC";
			$sqlnotVvisitor    = $this->db->select($selectnotVvisitor);
			
			if($sqlnotVvisitor){
				while($readNotVvis   = $sqlnotVvisitor->fetch_assoc()){
					$resultNotVvis[] = $readNotVvis; 
				}
				return $resultNotVvis;
			}
			
		}
		
		
		public function registerVisitor(){
			
			$selectRegvisitor = "SELECT * FROM `tbl_registration` WHERE `deleted` = '0'
								 ORDER BY id DESC";
			$sqlRegvisitor    = $this->db->select($selectRegvisitor);
			
			if($sqlRegvisitor){
				while($readRegvisitor   = $sqlRegvisitor->fetch_assoc()){
					$resultRegvisitor[] = $readRegvisitor; 
				}
				return $resultRegvisitor;
			}
			
		}
		
		
		public function deletedVisitor(){
			
			$selectDvisitor = "SELECT * FROM `tbl_registration` WHERE `deleted` = '1' 
								  ORDER BY id DESC";
			$sqlDvisitor    = $this->db->select($selectDvisitor);
			
			if($sqlDvisitor){
				while($readDvisitor   = $sqlDvisitor->fetch_assoc()){
					$resultDvisitor[] = $readDvisitor; 
				}
				return $resultDvisitor;
			}
			
		}
		
		public function appDaywise($dayWisedate){
			
			$selectAppList = "SELECT * FROM `tbl_appointment` WHERE `visitingDate` = '$dayWisedate'";
			$sqlAppList    = $this->db->select($selectAppList);
			
			if($sqlAppList){
				while($readAppList   = $sqlAppList->fetch_assoc()){
					$resultAppList[] = $readAppList; 
				}
				return $resultAppList;
			}
			
		}
		
		public function appDayToDaywise($srtDate,$endDate){
			
			$selectAppList = "SELECT * FROM `tbl_appointment` WHERE `visitingDate` >= '$srtDate' 
							 OR `visitingDate` <= '$endDate'";
							 
			$sqlAppList    = $this->db->select($selectAppList);
			
			if($sqlAppList){
				while($readAppList   = $sqlAppList->fetch_assoc()){
					$resultAppList[] = $readAppList; 
				}
				return $resultAppList;
			}
			
		}
	
}
