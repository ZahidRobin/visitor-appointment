<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>

	<br/>					
	<div class="col-sm-12">
		<div class="well well-default text-center">
			<h3><b>View Visitor Report</b></h3>
		</div>
		<div class="col-sm-8 col-sm-offset-2">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b> Day Wise</b></h4></div>
				<div class="panel-body">
					<form class="form-horizontal" target="_blank" action="../pdf/appointmentList.php" method="post">
						<div class="form-group">
							<label class="control-label col-sm-2" for="datepicker">Day Wise:</label>
							<div class="col-sm-8">
								<input type="text" required="" class="form-control" id="datepicker1" placeholder="select Date" name="dayWisedate">
							</div>
					<div class="col-sm-2">
						<button type="submit" name="dayWise" class="btn btn-primary">Show</button>
					</div>
						</div>
					</form>
					
				</div>
			</div>
		</div>
		
		
		<div class="col-sm-8 col-sm-offset-2">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b> Day To Day Wise</b></h4></div>
				<div class="panel-body">
					<form class="form-horizontal" target="_blank" action="../pdf/appointmentList.php" method="post">
						<div class="form-group">
							<label class="control-label col-sm-2" for="datepicker">Day To Day Wise:</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="datepicker2" placeholder="select Date" name="srtDate">
							</div>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="datepicker" placeholder="select Date" name="endDate">
							</div>
							<div class="col-sm-2">
								<button type="submit" name="dayTodayWise" class="btn btn-primary">Show</button>
							</div>
						</div>
					</form>
					
				</div>
			</div>
		</div>
	</div>



<?php include "dinc/footer.php" ;?>	