<?php
   include "php/lib/appSession.php";
   Session :: checkappSession();
   include "php/config/config.php";
   include "php/lib/DB.php";
   include "php/lib/helpers.php";
   
   $db   = new DataBase();
   $help = new Helpers();
   
   $path    = $_SERVER['SCRIPT_FILENAME'];
   $current = basename($path,".php");
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="shortcut icon" href="asset/facicon.png"/>
      <title><?php echo $help->title(); ?> - <?php echo TITLE ;?></title>
      <!-- Bootstrap core CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <!-- Custom styles for this template -->
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js"></script>
      <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css" rel="stylesheet"/>
      <link href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>
      <link rel="stylesheet" href="asset/jQuery.ui.css">
      <link rel="stylesheet" href="asset/my.css"/>
      <script src="asset/jquery-2.1.4.min.js"></script>
      <script src="asset/jQuery.ui.js"></script>
      <script src="asset/my.js"></script>
   </head>
   <body>
      <div class="container text-center">