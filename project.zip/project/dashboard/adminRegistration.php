<?php

include "../php/lib/session.php";
Session ::checkLogin();
include "../php/classes/adminLogin.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";

$adminLogin = new adminLogin();

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['regAdmin'])){
	
	$register = $adminLogin->regAdmin($_POST);
	
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin Login - Samart Corporation</title>
		<link rel="shortcut icon" href="../asset/facicon.png"/>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">	
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js"></script>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
		<br/><br/><br/><br/><br/><br/><br/><br/>
		<div class="col-sm-4 col-sm-offset-4">
			<div class="panel panel-default">
				<div class="panel-heading text-center"><b><i class="fas fa-registered"></i> Admin Registration</b></div>
				<div class="panel-body">
					<form class="form-horizontal" action="" method="post">
					
					<?php
						if(isset($register)){
							echo $register;
						}
					
					?>
					
					
						<div class="form-group">
							<div class="col-sm-12">
								<input type="text" class="form-control" placeholder="Admin Name" name="adminName">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="text" class="form-control" placeholder="Admin Email" name="adminEmail">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="password" class="form-control" placeholder="Admin Password" name="adminPassword">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<button type="submit" name="regAdmin" class="btn btn-default btn-block">
									<i class="fas fa-registered"></i>  Admin Registration
								</button>
							</div>
						</div>
						
						<a class="btn btn-link" href="adminLogin.php">Already have an account ?</a>
					</form>
					
				</div>
			</div>
		</div>
	</body>
</html>	
	
	
	
	
	
	
	
	
