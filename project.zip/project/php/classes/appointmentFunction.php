<?php
class appointmentFunctiuon{
	
	public $db;
	public $help;
	
	public function __construct(){
		
		$this->db = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function appointmentCreate($data){
		
		$vName    = mysqli_real_escape_string($this->db->link,$data['vName']);
		$vContact = mysqli_real_escape_string($this->db->link,$data['vContact']);
		$vNID     = mysqli_real_escape_string($this->db->link,$data['vNID']);
		$vCOmpany = mysqli_real_escape_string($this->db->link,$data['vCOmpany']);
		$vType    = mysqli_real_escape_string($this->db->link,$data['vType']);
		$visitingDate = mysqli_real_escape_string($this->db->link,$data['visitingDate']);
		$meetWith = mysqli_real_escape_string($this->db->link,$data['meetWith']);
		
		$appCrtId   = Session :: get('empId');
		$appCrtName = Session :: get('empName');
		
		$vName    = $this->help->validation($vName);
		$vContact = $this->help->validation($vContact);
		$vNID     = $this->help->validation($vNID);
		$vCOmpany = $this->help->validation($vCOmpany);
		$vType    = $this->help->validation($vType);
		$visitingDate = $this->help->validation($visitingDate);
		$meetWith = $this->help->validation($meetWith);
		
		if($vName == "" OR $vContact == "" OR $vNID == "" OR $vCOmpany == "" OR $vType == "" 
			OR $visitingDate == ""){
			
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			Filed must not be empty !  
			</div>
			</div>
			</div>';
			return $msg;
			
		}else if($meetWith == ""){
		 	
			$insart = "INSERT INTO `tbl_appointment`
			(`visitorName`, `visitorCompany`, `visitorType`,`visitorNID`, 
			`visitorReg_phoneNum`,`visitingDate`,appointmentWith , `appointmrntCreator`) 
			VALUES ('$vName','$vCOmpany','$vType','$vNID','$vContact','$visitingDate',
			'$appCrtName','$appCrtId')";
		 	
			$sql   = $this->db->insart($insart);
		 	
			if($sql){
			 	
				Session ::set("loginMsg",'<div class="form-group">
										
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					'.$vName.' Your appointment create successfull !
					</div>
					</div>
					</div>');
											  
				header("Location:visitorList.php");
			 	
			 	
			}else{
			 	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your appoinment not create !
				</div>
				</div>
				</div>';

				return $msg;
			}
		 	
		 	
		}else{
		 	
		 	
			$insart = "INSERT INTO `tbl_appointment`
			(`visitorName`, `visitorCompany`, `visitorType`,`visitorNID`, 
			`visitorReg_phoneNum`,`visitingDate`,appointmentWith , `appointmrntCreator`) 
			VALUES ('$vName','$vCOmpany','$vType','$vNID','$vContact','$visitingDate',
			'$meetWith','$appCrtId')";
		 	
			$sql   = $this->db->insart($insart);
		 	
			if($sql){
			 	
				Session ::set("loginMsg",'<div class="form-group">
									
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					'.$vName.' Your appointment create successfull !
					</div>
					</div>
					</div>');
											  
				header("Location:visitorList.php");
			 	
			 	
			}else{
			 	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your appoinment not create !
				</div>
				</div>
				</div>';

				return $msg;
			}
		 	
		 	
		}
	}
	
	public function appointmentList(){
		
		date_default_timezone_set('Asia/Dhaka');
		$date      = date("Y-m-d");
		$empId     = Session :: get('empId');
		
		$selectApp = "SELECT * FROM `tbl_appointment` WHERE `appointmrntCreator` = '$empId' 
					   AND visitingDate = '$date' AND checkOut = ''  ORDER BY id DESC";
					   
		$sql       = $this->db->select($selectApp);
		
		if($sql){
			while($readApp = $sql->fetch_assoc()){
				$resultApp[] = $readApp;
			}
			return $resultApp;
			
		}
		
	}
	
	public function appointmentInfo($id){
		
		$selectAppInfo  = "SELECT `id`, `visitorName`, `visitorCompany`, `visitorType`, `visitorNID`, 
					      `visitorReg_phoneNum`, `visitingDate`, `appointmentWith` 
					      FROM `tbl_appointment`  WHERE `id` = '$id'";
					   
		$sql            = $this->db->select($selectAppInfo);
		$resultAppInfo  = $sql->fetch_assoc();
		return $resultAppInfo;
		
	}
	
	
	public function appointmentUpdate($data){
		
		
		$id       = mysqli_real_escape_string($this->db->link,$data['id']);
		$vName    = mysqli_real_escape_string($this->db->link,$data['vName']);
		$vContact = mysqli_real_escape_string($this->db->link,$data['vContact']);
		$vNID     = mysqli_real_escape_string($this->db->link,$data['vNID']);
		$vCOmpany = mysqli_real_escape_string($this->db->link,$data['vCOmpany']);
		$vType    = mysqli_real_escape_string($this->db->link,$data['vType']);
		$visitingDate = mysqli_real_escape_string($this->db->link,$data['visitingDate']);
		$meetWith = mysqli_real_escape_string($this->db->link,$data['meetWith']);
		
		$appCrtId   = Session :: get('empId');
		$appCrtName = Session :: get('empName');
		
		$vName    = $this->help->validation($vName);
		$vContact = $this->help->validation($vContact);
		$vNID     = $this->help->validation($vNID);
		$vCOmpany = $this->help->validation($vCOmpany);
		$vType    = $this->help->validation($vType);
		$visitingDate = $this->help->validation($visitingDate);
		$meetWith = $this->help->validation($meetWith);
		
		if($vName == "" OR $vContact == "" OR $vNID == "" OR $vCOmpany == "" OR $vType == "" 
			OR $visitingDate == ""){
			
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			Filed must not be empty !  
			</div>
			</div>
			</div>';
			return $msg;
			
		}else if($meetWith == ""){
		 	
			$update = "UPDATE `tbl_appointment`
						SET
						`visitorName` = '$vName',
					    `visitorCompany` = '$vCOmpany',
					    `visitorType` = '$vType',
					    `visitorNID` = '$vNID',
					    `visitorReg_phoneNum` = '$vContact',
					    `visitingDate` = '$visitingDate',
					    `appointmentWith` = '$appCrtName'
						WHERE
						`id` = '$id'";
		 	
			$sql   = $this->db->update($update);
		 	
			if($sql){
			 	
				Session ::set("loginMsg",'<div class="form-group">
										
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					'.$vName.' Your appointment Update successfull !
					</div>
					</div>
					</div>');
											  
				header("Location:visitorList.php");
			 	
			 	
			}else{
			 	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your appoinment not Update !
				</div>
				</div>
				</div>';

				return $msg;
			}
		 	
		 	
		}else{
		 	
		 	
			$update = "UPDATE `tbl_appointment`
						SET
						`visitorName` = '$vName',
					    `visitorCompany` = '$vCOmpany',
					    `visitorType` = '$vType',
					    `visitorNID` = '$vNID',
					    `visitorReg_phoneNum` = '$vContact',
					    `visitingDate` = '$visitingDate',
					    `appointmentWith` = '$meetWith'
						WHERE
						`id` = '$id'";
		 	
			$sql   = $this->db->update($update);
		 	
			if($sql){
			 	
				Session ::set("loginMsg",'<div class="form-group">
									
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					'.$vName.' Your appointment Update successfull !
					</div>
					</div>
					</div>');
											  
				header("Location:visitorList.php");
			 	
			 	
			}else{
			 	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your appoinment not Update !
				</div>
				</div>
				</div>';

				return $msg;
			}
		 	
		 	
		}
		
		
	}
	
	public function appCheckinInfo($data){
		
		$select          = "SELECT * FROM `tbl_appointment` WHERE `id` = '$data'";
		$sql             = $this->db->select($select);
		$resultcheckInfo = $sql->fetch_assoc();
		
		return $resultcheckInfo;
	}
	
	public function appCheckInCreate($data){
		
		date_default_timezone_set('Asia/Dhaka');
		$Time       = date("h:i:s");
		
		$id  		= mysqli_real_escape_string($this->db->link,$data['id']);
		$vName 		= mysqli_real_escape_string($this->db->link,$data['vName']);
		$driverName = mysqli_real_escape_string($this->db->link,$data['driverName']);
		$vcle_no    = mysqli_real_escape_string($this->db->link,$data['vcle_no']);
		$prk_loc    = mysqli_real_escape_string($this->db->link,$data['prk_loc']);
		$gpMember   = mysqli_real_escape_string($this->db->link,$data['gpMember']);
		
		$vName      = $this->help->validation($vName);
		$driverName = $this->help->validation($driverName);
		$vcle_no    = $this->help->validation($vcle_no);
		$prk_loc    = $this->help->validation($prk_loc);
		$gpMember   = $this->help->validation($gpMember);
		
		
		
		$checkIn   = "UPDATE `tbl_appointment` 
					  SET 
					  `vcleDriverNmae`='$driverName',
					  `vcleNo`='$vcle_no',
					  `parkingLocation`='$prk_loc',
					  `visitorGroupMember`='$gpMember',
					  `checkIn`='Y',
					  `checkInTime`='$Time' 
					  WHERE 
					  `id` = '$id'";
		$sql      = $this->db->update($checkIn);
		
		if($sql){
			
			Session ::set("loginMsg",'<div class="form-group">
									
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					<b>'.$vName.'</b> Your Check In successfull !
					</div>
					</div>
					</div>');
											  
				header("Location:visitorList.php");
			
		}else{
			
			$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your are not Check In !
				</div>
				</div>
				</div>';

				return $msg;
			}
			
	}
	
	
	public function printVisitorCard($id){
		
		$select = "SELECT `id`,`visitorName`,`visitorCompany`,`appointmentWith`,printHowMuch
				  FROM `tbl_appointment` WHERE `id` = '$id'";
		$sql    = $this->db->select($select);
		$result = $sql->fetch_assoc();
		return $result;
	}
	
	
	
	public function meetingstart($meeting){
		
		date_default_timezone_set('Asia/Dhaka');
		$Time   = date("h:i:s");
		
		$update = "UPDATE `tbl_appointment` 
				   SET 
				   `mettingStart`='Y',
				   `meeting_start_time`='$Time'
				   WHERE `id` = '$meeting'";
		$sql   = $this->db->update($update);
		
		if($sql){
			Session ::set("loginMsg",'<div id="myModal" class="modal fade"  role="dialog">
								  <div class="modal-dialog modal-sm" >
								  <div class="modal-content">
                                  <div class="modal-body text-center" >
	                              <p class="h3 green">
	                              <i class="fa fa-5x fa fa-check-circle"></i></p>
	                              <p class="h4">Success !</p>
	                              <b> ID No.'.$meeting.'</b>
	                              <p>Your Meeting Start Successful</p>
	                              <p></p>
	                              <br/>
                                  </div>
                                  </div>
                                  </div>
								  </div>');
			header("Location:visitorList.php");
			
		}else{
			Session ::set("loginMsg",'<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert">
					<i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
					Your meeting not started.!
					</div>
					</div>
					</div>');

		header("Location:visitorList.php");
		}
		
	}
	
	
	
	
	public function checkOutStart($chekOut){
		
		date_default_timezone_set('Asia/Dhaka');
		$Time   = date("h:i:s");
		
		$update = "UPDATE `tbl_appointment` 
				   SET 
				   `checkOut`     ='Y',
				   `checkOutTime` ='$Time'
				   WHERE `id`     = '$chekOut'";
		$sql   = $this->db->update($update);
		
		if($sql){
			Session ::set("loginMsg",'<div id="myModal" class="modal fade"  role="dialog">
								  <div class="modal-dialog modal-sm" >
								  <div class="modal-content">
                                  <div class="modal-body text-center" >
	                              <p class="h3 green">
	                              <i class="fa fa-5x fa fa-check-circle"></i></p>
	                              <p class="h4">Success !</p>
	                              <b> ID No.'.$chekOut.'</b>
	                              <p>Your Check Out Successful</p>
	                              <p></p>
	                              <br/>
                                  </div>
                                  </div>
                                  </div>
								  </div>');
			header("Location:visitorList.php");
			
		}else{
			Session ::set("loginMsg",'<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert">
					<i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
					Your Check Out not successfull!
					</div>
					</div>
					</div>');

		header("Location:visitorList.php");
		}
		
	}
	
	public function searchByType($vSearchType){
		
		date_default_timezone_set('Asia/Dhaka');
		$date   = date("Y-m-d");
		$empId  = Session :: get('empId');
		
		$select = "SELECT * FROM `tbl_appointment` WHERE `appointmrntCreator` = '$empId' 
				   AND visitingDate = '$date' AND checkOut = '' AND 
				   visitorType = '$vSearchType' ORDER BY id DESC";
		$sql    = $this->db->select($select);
		
		if($sql){
			while($readVSlist = $sql->fetch_assoc()){
				$resultVSlist[] = $readVSlist;
			}
			return $resultVSlist;
			
		}
		
	}
	
	public function searchById($vSearchId){
		
		date_default_timezone_set('Asia/Dhaka');
		$date   = date("Y-m-d");
		$empId  = Session :: get('empId');
		
		$select = "SELECT * FROM `tbl_appointment` WHERE id = '$vSearchId' AND 
				  `appointmrntCreator` = '$empId' AND visitingDate = '$date' AND 
				   checkOut = '' ORDER BY id DESC";
				   
		$sql    = $this->db->select($select);
		
		if($sql){
			while($readVSlist = $sql->fetch_assoc()){
				$resultVSlist[] = $readVSlist;
			}
			return $resultVSlist;
			
		}
		
	}
}
?>