<?php include "inc/header.php"; ?>
<?php
   $loginMsg = Session :: get('loginMsg');
   if(isset($loginMsg)){
   	echo $loginMsg;
   }
   Session :: set('loginMsg',NULL);
   
   ?>
<br/><br/><br/><br/><br/><br/><br/>	
<h1 class="col-xs-12 col-sm-12"><b><i class="fas fa-th"></i> Smart Corporation</b></h1>
<h3 class="col-xs-12 col-sm-12">Appointment Management System</h3>
<div class="clearfix">&nbsp;</div>
<a href="" data-toggle="modal" data-target=".bd-example-modal-lg1" class="btn btn-dark col-sm-12 col-md-2">
<i class="fab fa-windows"></i> Process
</a>
&nbsp;
<a href="createAppointment.php" class="btn btn-dark col-sm-12 col-md-2">
<i class="fas fa-plus-square"></i> Create Appointment
</a>
&nbsp;
<a href="registration.php" class="btn btn-dark col-sm-12 col-md-2">
<i class="fas fa-registered"></i> Visitor Registration
</a>
&nbsp;
<a href="visitorList.php" class="btn btn-dark col-sm-12 col-md-2">
<i class="fas fa-list-alt"></i> Visitor List
</a>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<div class="modal fade bd-example-modal-lg1">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title text-center" id="exampleModalLabel"></h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
               <div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding-top: 20px; padding-bottom: 30px;">
                  <h4 class="col-sm-12"><b>- কি ভাবে ব্যবহার করবেন -</b></h4>
                  <br/><br/>
                  <div class="col-sm-12 col-md-12 text-left">
                     <b>১ম ধাপঃ-</b> আপনি প্রথমে Company Id নাম্বার দিয়ে 
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
         </div>
      </div>
   </div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
   $(window).on('load',function(){
       $('#myModal').modal('show');
       
   });
   
   $(window).on('load',function(){
       setTimeout(function() {
     		$('#myModal').modal('hide');
     	}, 3000);
   });
   
</script>