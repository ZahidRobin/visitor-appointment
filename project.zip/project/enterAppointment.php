<?php
   include "php/lib/appSession.php";
   Session ::checkappLogin();
   include "php/config/config.php";
   include "php/lib/DB.php";
   include "php/lib/helpers.php";
   include "php/classes/appointmentLogin.php";
   
   $login = new appLogin();
   $db    = new DataBase();
   $help  = new Helpers();
   
   if($_SERVER['REQUEST_METHOD'] == "POST"){
   	
   	$appId 		   = $_POST['appId'];
   	$appLoginCheck = $login->getAppLogin($appId);
   	
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Enter Appointment</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <!-- Custom styles for this template -->
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js"></script>
      <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css" rel="stylesheet"/>
   </head>
   <body>
      <br/><br/><br/><br/><br/><br/><br/><br/>
      <div class="container">
         <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <?php 
                  if(isset($appLoginCheck)){
                  	echo $appLoginCheck;
                  }
                  
                  ?>
               <form action="" method="post">
                  <div class="input-group">
                     <div class="input-group-prepend">
                        <span class="input-group-text bg-dark" id="basic-addon1" style="color: #ffffff;">
                        <i class="fas fa-user"></i> &nbsp; User Id
                        </span>
                     </div>
                     <input type="text" class="form-control" name="appId" id="" placeholder="Appointment Creator Id" >
                     <div class="input-group-append">
                        <button class="btn btn-dark" type="submit">
                        <i class="fas fa-sign-in-alt"></i> Enter
                        </button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </body>
</html>