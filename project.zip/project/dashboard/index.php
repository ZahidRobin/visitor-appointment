<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/CountFunction.php";
include "../php/classes/adminFunction.php";
$admin_Info = new adminInfo();
$count      = new Count();
date_default_timezone_set('Asia/Dhaka');
$date      = date("Y-m-d");

$currentApp = $admin_Info->currentAppoinment();
?>

<div id="page-wrapper">
	<div class="container-fluid">
		<!-- Page Heading -->
		<div class="row" id="main" >
					
			<div class="col-sm-12">
					
				<div class="col-sm-12 col-md-3">
					<div class="col-sm-12 well text-center" id="content">
						<h1 style="font-size: 50px !important;"><i class="fas fa-calendar-plus"></i></h1>
						<h4>New Appointment</h4>
						<h3><b><?php echo $count->appointmentCount() ;?></b></h3>
					</div>
				</div>
					
				<div class="col-sm-12 col-md-3">
					<div class="col-sm-12 well text-center" id="content">
						<h1 style="font-size: 50px !important;"><i class="fas fa-check-square"></i></h1>
						<h5>Today</h5>
						<h5><b><?php echo $count->CheckinCount() ;?></b> - Check In</h5>
						<h5><b><?php echo $count->CheckOutCount() ;?></b> - Check out</h5>
					</div>
				</div>
					
				<div class="col-sm-12 col-md-3">
					<div class="col-sm-12 well text-center" id="content">
						<h1 style="font-size: 50px !important;"><i class="fas fa-industry"></i></h1>
						<h4>Visitor in factory</h4>
						<h3><b><?php echo $count->visitorInFactory() ;?></b></h3>
					</div>
				</div>
					
				<div class="col-sm-12 col-md-3">
					<div class="col-sm-12 well text-center" id="content">
						<h1 style="font-size: 50px !important;"><i class="fas fa-user-times"></i></h1>
						<h4>Total Deleted Visitor</h4>
						<h3><b><?php echo $count->deletedVisitor() ;?></b></h3>
					</div>
				</div>

			</div>
					
		</div>
		<!-- /.row -->
					
		<div class="panel panel-default">
			<div class="panel-heading text-center">
				<b><h4>Current Date Appointment</h4>
				<p><?php echo $help->Formate($date) ;?></p> </b>
			</div>
			<div class="panel-body">
				<table id="example" class="table table-striped table-bordered" style="width:100%">
					<thead>
						<tr>
							<th width="7%" title="Serial No">Sl</th>
							<th title="Visitor Imge">Imge</th>
							<th title="Visitor Appointment Id">App Id</th>
							<th title="Visitor Name">Name</th>
							<th title="Visitor Type">Type</th>
							<th title="Visitor NID/Passport">NID/Passort</th>
							<th title="Visitor Contact">Contact</th>
							<th>Control</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$i = 0;
					if($currentApp){
						foreach($currentApp as $value){
								$i++;
					?>
					
						<tr>
							<td><?php echo $i ;?></td>
							<td>
							<img src="../captureImge/<?php echo $value['id'];?>.jpg" style="background: url('../asset/manIconBg.png'); width: 40px;height: 40px;
                        border-radius: 5px;"/>
							</td>
							<td><?php echo $value['id'] ;?></td>
							<td><?php echo $value['visitorName'] ;?></td>
							<td><?php echo $value['visitorType'] ;?></td>
							<td><?php echo $value['visitorNID'] ;?></td>
							<td><?php echo $value['visitorReg_phoneNum'] ;?></td>
							<td>
								<a href="" class="btn btn-default btn-sm" title="View visitor details" 
                	data-toggle="modal" data-target=".v<?php echo $value['id'] ;?>">
									<i class="fas fa-eye"></i>
								</a>
								<?php if($value['checkIn'] != "" ){ ?>								
								
								<a target="_blank" href="../pdf/VisiorDetails.php?id=<?php echo $value['id'] ;?>" class="btn btn-default btn-sm" title="Print visitor Info">
									<i class="fas fa-print"></i>
								</a>
								<?php }?>
								
							</td>
							
          <div class="modal fade v<?php echo $value['id'];?>">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title text-center" id="exampleModalLabel"></h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
                                    <h2 class="col-sm-12 text-center">Visitor Details</h2>
                                    <br/><br/><br/>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 col-md-12 text-left">
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
                                          <div class="col-sm-9">
                                             <div class="thumbnail col-sm-8">
                                                <img src="../captureImge/<?php echo $value['id'];?>.jpg" style="background: url('../asset/manIconView.jpg') !important; width: 200px; height: 200px;" class="" >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-4 col-form-label text-left"><b>Visitor Name</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorName'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="2" class="col-sm-4 col-form-label text-left"><b>Visitor Company</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorCompany'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="3" class="col-sm-4 col-form-label text-left"><b>Visitor Contact No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorReg_phoneNum'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="4" class="col-sm-4 col-form-label text-left"><b>NID/Passport No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorNID'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visitor Type</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorType'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Metting With</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['appointmentWith'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visiting Date</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $help->Formate($value['visitingDate']);?></label>
                                          </div>
                                       </div>
                                       
                                       
                                       
                                       
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check IN</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php 
                                                if( $value['checkIn'] == ""){
                                                	echo "NO";
                                                }else{
                                                	echo "YES";
                                                }
                                                ?>
                                             </label>
                                          </div>
                                       </div>
                                       
                                       
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check IN Time</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php echo $value['checkInTime'] ;?>
                                             </label>
                                          </div>
                                       </div>
                                       
                                       
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check Out</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php 
                                                if( $value['checkOut'] == ""){
                                                	echo "NO";
                                                }else{
                                                	echo "YES";
                                                }
                                                ?>
                                             </label>
                                          </div>
                                       </div>
                                       
                                         <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check Out Time</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php echo $value['checkOutTime'] ;?>
                                             </label>
                                          </div>
                                       </div>
                                       
                                       
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
						</tr>
						<?php }} ?>
					</tbody>
				</table>
			</div>
		</div>
					
	</div>
	<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
			
			
			

			
			
			
			
			
<?php include "dinc/footer.php" ;?>	