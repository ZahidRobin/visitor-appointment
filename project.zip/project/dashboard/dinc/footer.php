</div><!-- /#wrapper -->

		<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
		<script src="dasset/jQuery.ui.js"></script>
		<script src="dasset/my.js"></script>
	</body>
</html>
