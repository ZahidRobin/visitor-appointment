<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/registrationFunction.php";
   $regFunction = new Registration();
   
   if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['delRegInfo'])){
   	$deleteReginfo = $regFunction->delRegInfo($_POST);
   }
   $regInfo     = $regFunction->getRegistrationList();
   ?>
<br/><br/>
<div class="row" style="border-radius:4px; margin-top: 20px; padding: 20px;">
   <h2 class="col-sm-12"><b><i class="fas fa-th"></i> Smart Corporation</b></h2>
   <h4 class="col-sm-12">Visitor Registartion List</h4>
   <br/><br/><br/>
   <div class="col-sm-12 col-md-12" style="border: 1px solid #343A40; border-radius:4px; padding: 20px;">
      <div class="table-responsive">
         <?php if(isset($deleteReginfo)){echo $deleteReginfo;}?>
         <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
               <tr>
                  <th title="Serial No">Sl No</th>
                  <th title="Visitor Imge">Imge</th>
                  <th title="Visitor Name">Name</th>
                  <th title="Visitor Company">Company</th>
                  <th title="Visitor NID/Passport">NID/Passort</th>
                  <th title="Visitor Contact">Contact</th>
                  <th title="Visitor Type">Type</th>
                  <th title="Added Time">Added Time</th>
                  <th>Control</th>
               </tr>
            </thead>
            <tbody>
               <?php
                  $i = 0;
                  if($regInfo){
                  	foreach($regInfo as $value){
                  		$i++;
                  ?>
               <tr>
                  <td><?php echo $i ;?></td>
                  <td>
                     <?php if($value['visitorPhoto'] != ""){ ?>
                     <img src="<?php echo $value['visitorPhoto'] ;?>" 
                        alt="<?php echo $value['visitorName'] ;?>" height="60px" width="60px"/>
                     <?php }else{ ?>	
                     <?php echo $value['visitorName'] ;?> Imge is empty !
                     <?php }?>			
                  </td>
                  <td><?php echo $value['visitorName'] ;?></td>
                  <td><?php echo $value['visitorCompany'] ;?></td>
                  <td><?php echo $value['visitorNidPassport'] ;?></td>
                  <td><?php echo $value['visitorContactNo'] ;?></td>
                  <td><?php echo $value['visitorType'] ;?></td>
                  <td><?php echo $help->Formate_2($value['regTime']) ;?></td>
                  <td>
                     <a href="updateReg.php?id=<?php echo $value['id'] ;?>" class="btn btn-dark btn-sm" title="Edit Visitor Registartion">
                     <i class="fas fa-pen-square"></i>
                     </a>
                     <a href="" class="btn btn-dark btn-sm" title="Delete Visitor Registartion"
                        data-toggle="modal" data-target=".d<?php echo $value['id'] ;?>">
                     <i class="fas fa-trash-alt"></i>
                     </a>
                  </td>
                  <div class="modal fade d<?php echo $value['id'] ;?>">
                     <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                           <div class="modal-content">
                              <div class="modal-body text-center">
                                 <h1 style="font-size: 70px;"><i class="fas fa-question-circle"></i></h1>
                                 <p>Are you sure to delete ? </p>
                                 <form action="" method="post">
                                    <input type="hidden" value="<?php echo $value['id'] ;?>" name="id"/>
                                    <button type="submit" name="delRegInfo" class="btn btn-success btn-sm">
                                    <i class="fas fa-check-circle"></i> YES
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                                    <i class="fas fa-times-circle"></i> NO
                                    </button>
                                 </form>
                                 <br/><br/>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </tr>
               <?php }} ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<br/>

<?php include "inc/footer.php"; ?>