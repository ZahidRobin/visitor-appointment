<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/adminFunction.php";
$admin_Info = new adminInfo();
$regVisitor = $admin_Info->registerVisitor();
?>


	<br/>					
	<div class="col-sm-12">
		<div class="col-sm-12">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b>Deleted Visitor Details</b></h4></div>
				<div class="panel-body">
					<table id="example" class="table table-striped table-bordered" style="width:100%">
						<thead>
							<tr>
								<th title="Serial No">Sl</th>
								<th title="Visitor Imge">Imge</th>
								<th title="Visitor Appointment Id">App Id</th>
								<th title="Visitor Name">Name</th>
								<th title="Visitor Company">Company</th>
								<th title="Visitor Type">Type</th>
								<th title="Visitor NID/Passport">NID/Passort</th>
								<th title="Visitor Contact">Contact</th>
								<th width="10%">Control</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$i = 0;
						if($regVisitor){
							foreach($regVisitor as $value){
								$i++;
						?>
							<tr>
								<td><?php echo $i ;?></td>
								<td>
									<?php if($value['visitorPhoto'] != ""){ ?>
										<img src="../<?php echo $value['visitorPhoto'] ;?>" 
										alt="<?php echo $value['visitorName'] ;?>" height="60px" width="60px"/>
										<?php }else{ ?>	
										<?php echo $value['visitorName'] ;?> Imge is empty !
										<?php }?>			
								</td>
								<td><?php echo $value['id'] ;?></td>
								<td><?php echo $value['visitorName'] ;?></td>
								<td><?php echo $value['visitorCompany'] ;?></td>
								<td><?php echo $value['visitorType'] ;?></td>
								<td><?php echo $value['visitorNidPassport'] ;?></td>
								<td><?php echo $value['visitorContactNo'] ;?></td>
								<td>
									<a href="" class="btn btn-default btn-sm" title="View visitor details" 
                	data-toggle="modal" data-target=".v<?php echo $value['id'] ;?>">
										<i class="fas fa-eye"></i>
									</a>
									
									<a href="pdf/visitorCard.php" class="btn btn-default btn-sm" title="Print visitor Details">
										<i class="fas fa-print"></i>
									</a>
					
								</td>

            
								<div class="modal fade v<?php echo $value['id'] ;?>">
									<div class="modal-dialog modal-md">
										<div class="modal-content">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title text-center" id="exampleModalLabel"></h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true">&times;</span>
													</button>
												</div>
												<div class="modal-body">
								


<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
	<h2 class="col-sm-12 text-center">Visitor Details</h2><br/><br/><br/>
	<div class="clearfix"></div>
	<div class="col-sm-12 col-md-12 text-left">


		<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
				<div class="thumbnail col-sm-8">
					<?php if($value['visitorPhoto'] != ""){ ?>
										<img src="../<?php echo $value['visitorPhoto'] ;?>" 
										alt="<?php echo $value['visitorName'] ;?>" />
										<?php }else{ ?>	
										<?php echo $value['visitorName'] ;?> Imge is empty !
										<?php }?>
				</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="1" class="col-sm-4 col-form-label text-left"><b>Visitor Name</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['visitorName'] ;?></label>
			</div>
		</div>
		<div class="form-group row">
			<label for="2" class="col-sm-4 col-form-label text-left"><b>Visitor Company</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['visitorCompany'] ;?></label>
			</div>
		</div>
		<div class="form-group row">
			<label for="3" class="col-sm-4 col-form-label text-left"><b>Visitor Contact No</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['visitorContactNo'] ;?></label>
			</div>
		</div>
		<div class="form-group row">
			<label for="4" class="col-sm-4 col-form-label text-left"><b>NID/Passport No</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['visitorNidPassport'] ;?></label>
			</div>
		</div>
		
		
		<div class="form-group row">
			<label for="5" class="col-sm-4 col-form-label text-left"><b>Visitor Type</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['visitorType'] ;?></label>
			</div>
		</div>
		
		
		<div class="form-group row">
			<label for="5" class="col-sm-4 col-form-label text-left"><b>Creator Employe Id</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $value['employeId'] ;?></label>
			</div>
		</div>
		
		
		<div class="form-group row">
			<label for="5" class="col-sm-4 col-form-label text-left"><b>Created Time</b></label>
			<div class="col-sm-8">
				<label for="1" class="col-form-label text-left"><?php echo $help->Formate_2($value['regTime']) ;?></label>
			</div>
		</div>


	</div>
</div>

								
						
								
								
								
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</tr>

						<?php }} ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>



<?php include "dinc/footer.php" ;?>	