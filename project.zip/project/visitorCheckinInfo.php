<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/registrationFunction.php";
   include "php/classes/appointmentFunction.php";
   $regFunction = new Registration();
   $appFunction = new appointmentFunctiuon();
   
   if(isset($_GET['id'])){
   	$id = $_GET['id'];
   }else{
   	header("Location:visitorList.php");
   }
   
   if($_SERVER['REQUEST_METHOD'] == "POST"){
   	$appCheckInCreate = $appFunction->appCheckInCreate($_POST);
   }
   
   $appCheckIn = $appFunction->appCheckinInfo($id);
   $vType = $regFunction->selectVtype();
   ?>
<?php
   $id = $_GET['id'];
   $myfile = fopen("captureImge.txt", "wr") or die("Unable to open file!");
   fwrite($myfile, $id);
   fclose($myfile);
   ?>
<br/><br/>
<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
   <h2 class="col-sm-12">Visitor Check In Information</h2>
   <br/><br/><br/>
   <div class="clearfix"></div>
   <div class="col-sm-12 col-md-4">
      <div class="col-md-12">
         <div class="thumbnail">
            <div id="camera"></div>
         </div>
         <div class="col-sm-12"><br/>
            <button id="capture_btn" type="button" class="btn btn-dark btn-sm">
            Capture
            </button>
         </div>
      </div>
      <br/>
      <div class="col-md-12">
         <div class="thumbnail">
            <div id="show_saved_img"></div>
         </div>
      </div>
   </div>
   <div class="col-sm-12 col-md-8 text-left">
      <form class="form-horizontal" method="post" action="">
         <fieldset>
            <div class="form-group row">
               <label for="1" class="col-sm-3 col-form-label text-left"><b>Visitor Name</b></label>
               <div class="col-sm-9">
                  <input type="hidden" name="id" value="<?php echo $appCheckIn['id'] ;?>"/>
                  <input type="text" class="form-control" id="1" name="vName" readonly=""
                     value="<?php echo $appCheckIn['visitorName'] ?>" >
               </div>
            </div>
            <div class="form-group row">
               <label for="2" class="col-sm-3 col-form-label text-left"><b>Visitor Company</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="2" name="vCompany" readonly=""
                     value="<?php echo $appCheckIn['visitorCompany'] ?>" >
               </div>
            </div>
            <div class="form-group row">
               <label for="3" class="col-sm-3 col-form-label text-left"><b>Visitor Contact No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="3" name="vContact" readonly=""
                     value="<?php echo $appCheckIn['visitorReg_phoneNum'] ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="4" class="col-sm-3 col-form-label text-left"><b>NID/Passport No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="4" name="vNID" readonly="" 
                     value="<?php echo $appCheckIn['visitorNID'] ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="5" class="col-sm-3 col-form-label text-left"><b>Visitor Type</b></label>
               <div class="col-sm-9">
                  <select name="vType" disabled="disabled" class="form-control" id="5">
                     <option value="">- Select visitor Type -</option>
                     <?php 
                        if($vType){
                        	foreach($vType as $value){
                        	
                        		?>
                     <option
                        <?php
                           if( $appCheckIn['visitorType'] == $value['visitortype']){
                           	echo 'selected="selected"';
                           }
                           
                           ?>
                        value="<?php echo $value['visitortype'] ;?>">
                        <?php echo $value['visitortype'] ;?>
                     </option>
                     <?php }} ?>
                  </select>
               </div>
            </div>
            <div class="form-group row">
               <label for="6" class="col-sm-3 col-form-label text-left"><b>Meeting With</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="4"  name="vAppWith" readonly=""
                     value="<?php echo $appCheckIn['appointmentWith'] ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="6" class="col-sm-3 col-form-label text-left"><b>Vehicle</b></label>
               <div class="form-check">
                  <input class="form-check-input app" type="radio" name="vehicle" id="no" value="me" 
                     checked="checked" >
                  <label class="form-check-label" for="no" style="cursor: pointer;">
                  No
                  </label>
               </div>
               &nbsp;&nbsp;
               <div class="form-check">
                  <input class="form-check-input app" type="radio" name="vehicle" id="yes" value="another">
                  <label class="form-check-label" for="yes" style="cursor: pointer;">
                  Yes
                  </label>
               </div>
            </div>
            <div id="metting_with" >
               <div class="form-group row" >
                  <label for="7" class="col-sm-3 col-form-label text-left"><b>Driver Name</b></label>
                  <div class="col-sm-9">
                     <input type="text" class="form-control colo" id="7" name="driverName"
                        placeholder="Driver Name">
                  </div>
               </div>
               <div class="form-group row" >
                  <label for="7" class="col-sm-3 col-form-label text-left"><b>Vehicle No</b></label>
                  <div class="col-sm-9">
                     <input type="text" class="form-control colo" id="7" name="vcle_no"
                        placeholder="Vehicle No">
                  </div>
               </div>
               <div class="form-group row" >
                  <label for="7" class="col-sm-3 col-form-label text-left"><b>Parking Loaction</b></label>
                  <div class="col-sm-9">
                     <input type="text" class="form-control colo" id="7" name="prk_loc"
                        placeholder="Parking Loaction">
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="6" class="col-sm-3 col-form-label text-left"><b>Visitor With</b></label>
               <div class="form-check">
                  <input class="form-check-input vsw" type="radio" name="exampleRadios" id="Single" value="Single" 
                     checked="checked" >
                  <label class="form-check-label" for="Single" style="cursor: pointer;">
                  Single
                  </label>
               </div>
               &nbsp;&nbsp;
               <div class="form-check">
                  <input class="form-check-input vsw" type="radio" name="exampleRadios" id="Group" value="Group">
                  <label class="form-check-label" for="Group" style="cursor: pointer;">
                  Group
                  </label>
               </div>
            </div>
            <div id="group">
               <div class="form-group row" >
                  <label for="7" class="col-sm-3 col-form-label text-left"><b>Group Membar</b></label>
                  <div class="col-sm-9">
                     <textarea class="form-control colo" name="gpMember" placeholder="Group Member Name"></textarea>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="inputPassword" class="col-sm-3 col-form-label text-left"><b></b></label>
               <div class="col-sm-9">
                  <button type="submit" class="btn btn-dark">Check In</button>
                  <a href="visitorList.php" class="btn btn-secondary">Close</a>
               </div>
            </div>
         </fieldset>
      </form>
   </div>
</div>
<br/><br/>
<script src="webcam/jquery.js"></script>
<script type="text/javascript" src="webcam/webcam.js"></script>
<script>
   $(function(){
   		//give the php file path
   		webcam.set_api_url( 'captureFunction.php' );
   		webcam.set_swf_url( 'webcam/webcam.swf' );//flash file (SWF) file path
   		webcam.set_quality( 100 ); // Image quality (1 - 100)
   		webcam.set_shutter_sound( true,'webcam/shutter.mp3' ); // play shutter click sound
        
   		var camera = $('#camera');
   		camera.html(webcam.get_html(230, 250)); //generate and put the flash embed code on page
        
   		$('#capture_btn').click(function(){
   				//take snap
   				webcam.snap();
   				$('#show_saved_img').html('<h3>Please Wait...</h3>');
   			});
        
   
   		//after taking snap call show image
   		webcam.set_hook( 'onComplete', function(img){
   				$('#show_saved_img').html('<img src="' + img + '">');
   				//reset camera for the next shot
   				webcam.reset();
   			});
        
   	});
</script>
<?php include "inc/footer.php"; ?>