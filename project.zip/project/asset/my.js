  
 /*dataTable*/
  
  	$(document).ready(function() {
		$('#example').DataTable();
	}); 
	 
  /*end dataTable*/ 
    
    
   /* create Appointment*/
    
          
      $(document).ready(function() {
       $( window ).on( "load", function() {
        $("#metting_with").hide('fast');
      });
    });
      
      $(document).ready(function() {
       $( window ).on( "load", function() {
        $("#group").hide('fast');
      });
    });
    
    
    
      $(document).ready(function() {
        $(".app").click(function(){
          if($(this).val() === "me")
            $("#metting_with").hide("fast");
          if($(this).val() === "another")
            $("#metting_with").show("fast");
        });
      });
    
      $(document).ready(function() {
        $(".vsw").click(function(){
          if($(this).val() === "Single")
            $("#group").hide("fast");
          if($(this).val() === "Group")
            $("#group").show("fast");
        });
      });

	/*end create Appointment*/
	
	/*datepicker*/
	
	$(document).ready(function() {
			$( "#datepicker" ).datepicker({
				showOtherMonths: true,
				selectOtherMonths: false,
				changeMonth:true,
				changeYear:true,
				dateFormat: "yy-mm-dd",
				
			});
	      });
	
	

	
/*Ajax Search*/

	
	  $(document).ready(function(){
	  	
	  	$("#vName").keyup(function(){
			
	  		var vName = $(this).val();
	  		if(vName !== ''){
			  	$.ajax({
			  		
			  		url:"php/classes/checkVsearch.php",
			  		method:"POST",
			  		data:{vName:vName},
			  		dataType:"text",
			  		success:function(data){
			  			$('#show').fadeIn();
						$('#show').html(data);
					}
			  		
			  	});
			  	
			  }else{
			  	$('#show').html("");
			  }
	  		
	  		
	  	});
	  	
	  		$(document).on('click','tr',function(){
				var a = $(this).children("td:nth-child(1)").text();
				var b = $(this).children("td:nth-child(2)").text();
				var c = $(this).children("td:nth-child(3)").text();
				var d = $(this).children("td:nth-child(4)").text();
				var e = $(this).children("td:nth-child(5)").text();
				var f = $(this).children("td:nth-child(6)").text();
				$("input#vName").val(a);
				$("input#vContact").val(b);
				$("input#vNID").val(c);
				$("input#vCOmpany").val(d);
				$("select#vType").val(e);
				$('#show').fadeOut();
			});
	  	
	  	
	  	
	});
	
	
	
/*for auto modal	*/
	
	
    $(window).on('load',function(){
        $('#myModal').modal('show');
        
    });
    
    $(window).on('load',function(){
        setTimeout(function() {
			   		$('#myModal').modal('hide');
			   	}, 3000);
    });
	
	