<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/adminLogin.php";
$adminLogin = new adminLogin();

if($_SERVER['REQUEST_METHOD'] == "POST"){
	$changePass = $adminLogin->changePassword($_POST);
}
?>


	<br/>					
	<div class="col-sm-12">
		<div class="col-sm-10 col-sm-offset-1">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b> Change Password</b></h4></div>
				<div class="panel-body">
					<form class="form-horizontal" action="" method="post">
						
						
						
						
						<div class="form-group">
							<label class="control-label col-sm-3" for="Current"></label>
							<div class="col-sm-9">
								<?php 
						
								if(isset($changePass)){
									echo $changePass ;
								}
						
								?>
							</div>
						</div>
						
						
						<div class="form-group">
							<label class="control-label col-sm-3" for="Current">Current Password</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" id="Current" placeholder="Current Password" name="currPassword">
							</div>
						</div>
						
						
						
						<div class="form-group">
							<label class="control-label col-sm-3" for="New">New Password</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" id="New" placeholder="New Password" name="newPassword">
							</div>
						</div>
						
						
						
						<div class="form-group">
							<label class="control-label col-sm-3" for="e-type">Re-type New Password</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" id="e-type" placeholder="Re-type New Password" name="reNewPassword">
							</div>
						</div>
						
						
						
						
						<div class="form-group">
							<label class="control-label col-sm-3" for=""></label>
							<div class="col-sm-9">
								<button type="submit" class="btn btn-success btn-block"> Change Password</button>
							</div>
						</div>
					</form>
					
				</div>
			</div>
		</div>
	</div>


<?php include "dinc/footer.php" ;?>	