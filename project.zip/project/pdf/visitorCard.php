<?php
include "fpdf/fpdf.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";
include "../php/classes/appointmentFunction.php";
$db          = new DataBase();
$help        = new Helpers();
$appFunction = new appointmentFunctiuon();

if(isset($_GET['id'])){
	$id   = $_GET['id'];
	$printVcard  = $appFunction->printVisitorCard($id);

	$val  = $printVcard['printHowMuch'];
	$cunt = $val+1;
	
	$update = "UPDATE `tbl_appointment` SET `printHowMuch` = '$cunt' WHERE `id` = '$id'";
	$sql    = $db->update($update);
	
}else{
	header("Location:../visitorList.php");
}


date_default_timezone_set('Asia/Dhaka');
$dateTime = date("F j, Y, g:i a");



$pdf = new FPDF('P','mm', array(100, 153)); 

$pdf->Cell(2);
$pdf->AddPage();
$pdf->SetAuthor('Smart Corporsation | Eeastern Plaza | Pranto');
$pdf->SetTitle('Smart Corporsation | V.2.0');


$pdf->Rect(5, 5, 90, 76, 'D');//this line for boarder
$pdf->Rect(6, 6, 88, 74, 'D');//this line for boarder
$pdf->Ln(1);
$pdf->SetFont("Arial","B","20");
$pdf->Cell(28,5,'',0,0,'C',0);
$pdf->Cell(20,5,'VISITOR CARD',0,0,'C',0);
$pdf->Ln(6);
$pdf->SetFont("Arial","","12");
$pdf->Cell(25,5,'',0,0,'C',0);
$pdf->Cell(20,5,'Smart Corporation, Dhaka',0,0,'C',0);
$pdf->Ln(9);



$pdf->Cell(20,5,'Visitor No ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['id'],0,0,'L',0);
$pdf->Ln(5);


$pdf->Cell(20,5,'Date ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$dateTime,0,0,'L',0);


$pdf->Ln(5);
$pdf->Cell(20,5,'Name ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['visitorName'],0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(20,5,'From',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['visitorCompany'],0,0,'L',0);


$pdf->Ln(5);

$pdf->Cell(20,5,'To Meet',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['appointmentWith'],0,0,'L',0);


$pdf->Ln(19);


$pdf->SetFont("Arial","B","14");
$pdf->Cell(20,5,'Security Sign',0,0,'L',0);
$pdf->Cell(20,5,'',0,0,'L',0);
$pdf->Cell(20,5,'FD.Exe Sign',0,0,'L',0);

$pdf->Ln(5);

$pdf->SetFillColor(230,230,230);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,5,'Dear Visitor, if you could not meet your contract',0,0,'L',0);
$pdf->Ln(5);
$pdf->Cell(0,5,'person within 15 minutes please inform to the FD Exe.',0,0,'L',0);

$pdf->Ln(5);
$pdf->Cell(75,3,'','B',0,'C',0);

$pdf->Ln(10);



$pdf->SetFont("Arial","B","13");

$pdf->Rect(5, 86, 90, 56, 'D');//this line for boarder
$pdf->Rect(6, 87, 88, 54, 'D');//this line for boarder

$image1 = "../captureImge/".$printVcard['id'].".jpg";
$pdf->Cell( 30, 10, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 18,15), 0, 0, 'C', false );

//$pdf->Cell(25,5,'',0,0,'R',0);
$pdf->Cell(20,5,'Visitor Card',0,0,'L',0);
$pdf->Ln(6);
$pdf->SetFont("Arial","","10");
$pdf->Cell(25,5,'',0,0,'C',0);
$pdf->Cell(20,5,'Smart Corporation, Dhaka',0,0,'L',0);
$pdf->Ln(9);

$pdf->Ln(2);
$pdf->Cell(20,5,'Visitor No ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['id'],0,0,'L',0);
$pdf->Ln(5);



$pdf->Cell(20,5,'Date ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$dateTime,0,0,'L',0);


$pdf->Ln(5);
$pdf->Cell(20,5,'Name ',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['visitorName'],0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(20,5,'From',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['visitorCompany'],0,0,'L',0);


$pdf->Ln(5);

$pdf->Cell(20,5,'To Meet',0,0,'L',0);
$pdf->Cell(8,5,':',0,0,'C',0);
$pdf->Cell(60,5,$printVcard['appointmentWith'],0,0,'L',0);


$pdf->Output();



?>