<?php
class Registration{
	
	public $db;
	public $help;
	
	public function __construct(){
		
		$this->db   = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function selectVtype(){
		
		$select = "SELECT * FROM `tbl_visitortype` ORDER BY id DESC";
		$sql    = $this->db->select($select);
		
		if($sql){
			while($readVtype   = $sql->fetch_assoc()){
				$resultVtype[] = $readVtype;
			}
			return $resultVtype;
		}
		
		
	}
	
	
	public function appRegistaration($dataReg,$picReg){
				
		$vName    = mysqli_escape_string($this->db->link,$dataReg['vName']);
		$vCompany = mysqli_escape_string($this->db->link,$dataReg['vCompany']);
		$vContact = mysqli_escape_string($this->db->link,$dataReg['vContact']);
		$vNid     = mysqli_escape_string($this->db->link,$dataReg['vNid']);
		$vType    = mysqli_escape_string($this->db->link,$dataReg['vType']);
			
		$vName    = $this->help->validation($vName);
		$vCompany = $this->help->validation($vCompany);
		$vContact = $this->help->validation($vContact);
		$vNid     = $this->help->validation($vNid);
		$vType    = $this->help->validation($vType);
			
		$empId    = Session :: get('empId');
			
		$permited  = array('jpg', 'jpeg', 'png', 'gif');
		$file_name = $picReg['vPic']['name'];
		$file_size = $picReg['vPic']['size'];
		$file_temp = $picReg['vPic']['tmp_name'];

		$div            = explode('.', $file_name);
		$file_ext       = strtolower(end($div));
		$unique_image   = substr(md5(time()), 0, 10).'.'.$file_ext;
		$uploaded_image = "vImge/".$unique_image;

	
			
			
		$selectNID = "SELECT `visitorNidPassport` FROM `tbl_registration` 
		WHERE `visitorNidPassport` = '$vNid'";
		$sqlNid    = $this->db->select($selectNID);
			
			
		$selectCont = "SELECT `visitorContactNo` FROM `tbl_registration` 
		WHERE `visitorContactNo` = '$vContact'";
		$sqlContact = $this->db->select($selectCont);
			
			
			
		if($vName == "" OR $vCompany == "" OR $vContact == "" OR $vNid == ""){
				
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			Filed must not be empty !  
			</div>
			</div>
			</div>';

			return $msg;
				
		}elseif($sqlContact == TRUE){
				
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			This Contact No has been Already added !  
			</div>
			</div>
			</div>';

			return $msg;
				
		}elseif($sqlNid == TRUE){
				
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			This Nid has been Already added !  
			</div>
			</div>
			</div>';

			return $msg;
				
		}elseif($vType == ""){
				
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			Please Select Visitor Type !
			</div>
			</div>
			</div>';

			return $msg;
				
		}else if(!empty($file_name)){
				
			if(in_array($file_ext, $permited) === false){
		    	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				You can upload only:-'.implode(', ', $permited).'  
				</div>
				</div>
				</div>';

				return $msg;

			}else{
				
				if(move_uploaded_file($file_temp, $uploaded_image)){
					
					$insartReg = "INSERT INTO `tbl_registration`
					(`visitorName`, `visitorCompany`, `visitorContactNo`, 
					`visitorNidPassport`, `visitorType`, `visitorPhoto`, `employeId`) 
					VALUES ('$vName','$vCompany','$vContact','$vNid','$vType',
					'$uploaded_image','$empId')";
				
					$insert    = $this->db->insart($insartReg) ;
				
					if($insert){
			    	
						$msg = '<div class="form-group row">
						<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
						<div class="col-sm-9">
						<div class="alert alert-success" id="success-alert">
						<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
						<strong><i class="fas fa-check-circle"></i> Success! </strong>
						'.$vName.' Your Registration successfull !
						</div>
						</div>
						</div>';
				
						return $msg ;
			    	
					}else{
					
						$msg = '<div class="form-group row">
						<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
						<div class="col-sm-9">
						<div class="alert alert-danger" id="success-alert">
						<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
						<strong><i class="fas fa-times-circle"></i> Error ! </strong>
						Your registration not successfull !
						</div>
						</div>
						</div>';

						return $msg;
					
					
					}
					
				}else{
			  	
					$msg = '<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
					Imge size should be less then <b>1 MB</b>  
					</div>
					</div>
					</div>';

					return $msg;
				}
				
				
			}
				
		}else{
		 	
		 	
			$insartReg = "INSERT INTO `tbl_registration`
			(`visitorName`, `visitorCompany`, `visitorContactNo`, 
			`visitorNidPassport`, `visitorType`,`employeId`) 
			VALUES ('$vName','$vCompany','$vContact','$vNid','$vType','$empId')";
				
			$insert    = $this->db->insart($insartReg) ;
				
			if($insert){
			    	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-success" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-check-circle"></i> Success! </strong>
				'.$vName.' Your Registration successfull !
				</div>
				</div>
				</div>';
				
				return $msg ;
			    	
			}else{
					
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your registration not successfull !
				</div>
				</div>
				</div>';

				return $msg;
					
					
			}
				
		}
			
	}
	
	
	public function getRegistrationList(){
		
		$empId     = Session :: get('empId');
		$selectReg = "SELECT * FROM `tbl_registration` WHERE `employeId` = '$empId' AND 
					 `deleted` = '0' ORDER BY id DESC";
					 
		$sql       = $this->db->select($selectReg);
		
		if($sql){
			while($readReg   = $sql->fetch_assoc()){
				$resultReg[] = $readReg;
			}	
			
			return $resultReg ;	
		}
	
	}
	
	
	public function upRegInfo($id){
		
		$selectRegInfo = "SELECT * FROM `tbl_registration` WHERE `id` = '$id'";
		$sqlReg        = $this->db->select($selectRegInfo);
		$result        = $sqlReg->fetch_assoc();
		
		return $result;
	}
	
	
	public function updateFunction($regInfo,$regPic){
			
		$id       = mysqli_escape_string($this->db->link,$regInfo['id']);
		$vName    = mysqli_escape_string($this->db->link,$regInfo['vName']);
		$vCompany = mysqli_escape_string($this->db->link,$regInfo['vCompany']);
		$vContact = mysqli_escape_string($this->db->link,$regInfo['vContact']);
		$vNid     = mysqli_escape_string($this->db->link,$regInfo['vNid']);
		$vType    = mysqli_escape_string($this->db->link,$regInfo['vType']);
			
		$vName    = $this->help->validation($vName);
		$vCompany = $this->help->validation($vCompany);
		$vContact = $this->help->validation($vContact);
		$vNid     = $this->help->validation($vNid);
		$vType    = $this->help->validation($vType);

			
		$permited  = array('jpg', 'jpeg', 'png', 'gif');
		$file_name = $regPic['vPic']['name'];
		$file_size = $regPic['vPic']['size'];
		$file_temp = $regPic['vPic']['tmp_name'];

		$div            = explode('.', $file_name);
		$file_ext       = strtolower(end($div));
		$unique_image   = substr(md5(time()), 0, 10).'.'.$file_ext;
		$uploaded_image = "vImge/".$unique_image;

	
		$selectNID = "SELECT `visitorPhoto` FROM `tbl_registration` WHERE `id` = '$id'";
		$sqlNid    = $this->db->select($selectNID);
		$resultImg = $sqlNid->fetch_assoc();
		
		if($vName == "" OR $vCompany == "" OR $vContact == "" OR $vNid == ""){
			
			$msg = '<div class="form-group row">
			<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
			<div class="col-sm-9">
			<div class="alert alert-danger" id="success-alert">
			<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
			<strong><i class="fas fa-times-circle"></i> Error ! </strong>
			Field must not be empty !
			</div>
			</div>
			</div>';

			return $msg;
			
		}else if(empty($file_name)){
			
			$update = "UPDATE `tbl_registration` 
			SET 
			`visitorName`       ='$vName',
			`visitorCompany`    ='$vCompany',
			`visitorContactNo`  ='$vContact',
			`visitorNidPassport`='$vNid',
			`visitorType`       ='$vType' 
			WHERE 
			`id` = '$id'";
			$sql   = $this->db->update($update);
		 	
			if($sql){
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-success" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-check-circle"></i> Success! </strong>
				'.$vName.' Your Registration info Updated successfull !
				</div>
				</div>
				</div>';
				
				return $msg ;
			}else{
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				Your registration info not updated !
				</div>
				</div>
				</div>';

				return $msg;
			}
		}else{
			
			if(in_array($file_ext, $permited) === false){
		    	
				$msg = '<div class="form-group row">
				<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
				<div class="col-sm-9">
				<div class="alert alert-danger" id="success-alert">
				<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
				<strong><i class="fas fa-times-circle"></i> Error ! </strong>
				You can upload only:-'.implode(', ', $permited).'  
				</div>
				</div>
				</div>';

				return $msg;

			}
				
				unlink($resultImg['visitorPhoto']);
				
			if(move_uploaded_file($file_temp,$uploaded_image)){
				
				$update = "UPDATE `tbl_registration` 
				SET 
				`visitorName`       ='$vName',
				`visitorCompany`    ='$vCompany',
				`visitorContactNo`  ='$vContact',
				`visitorNidPassport`='$vNid',
				`visitorType`       ='$vType' ,
				`visitorPhoto`       ='$uploaded_image' 
				WHERE 
				`id` = '$id'";
				$sql   = $this->db->update($update);
		 	
				if($sql){
		 		
					$msg = '<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					'.$vName.' Your Registration info Updated successfull !
					</div>
					</div>
					</div>';
				
					return $msg ;
			 	
				}else{
			 	
					$msg = '<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
					Your registration info not updated !
					</div>
					</div>
					</div>';

					return $msg;
					
				}
				
			}else{
				
				$msg = '<div class="form-group row">
					<label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
					<div class="col-sm-9">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
						Imge Size must be less then <b>1 MB</b>
					</div>
					</div>
					</div>';

				return $msg;
				
				
			}
			
		}
	
			
			
	}
	
	public function delRegInfo($data){
		
		$id 	= $data['id'];
		$delete = "UPDATE `tbl_registration` SET `deleted`= '1' WHERE id = '$id'";
		$sql    = $this->db->update($delete);
		
		if($sql){
		 		
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-success" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-check-circle"></i> Success! </strong>
					 Your Registration info delete successfull !
					</div>
					</div>
					</div>';
				
					return $msg ;
			 	
				}else{
			 	
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger" id="success-alert">
					<button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>
					<strong><i class="fas fa-times-circle"></i> Error ! </strong>
					Your registration info not deleted !
					</div>
					</div>
					</div>';

					return $msg;
					
				}
		
	}
	
	
}
?>