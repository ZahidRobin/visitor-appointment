<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/adminFunction.php";
$admin_Info = new adminInfo();

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['upEmploye'])){
	
	$employeUpdate = $admin_Info->updateEmploye($_POST);
	
}

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['delEmploye'])){
	
	$employeDelete = $admin_Info->deleteEmploye($_POST);
	
}


$employe = $admin_Info->getEmploye();
?>
	<br/>					
	<div class="col-sm-12">
		<div class="col-sm-12">

			<div class="panel panel-default">
				<div class="panel-heading text-center">
				
				 <a href="addEmploy.php" class="pull-right btn btn-info">Add New</a>
				<h4><b> Employ List</b></h4></div>
				<div class="panel-body">
				
					<?php if(isset($employeUpdate)){ echo $employeUpdate ; } ?>
					<?php if(isset($employeDelete)){ echo $employeDelete ; } ?>
					
					
					<table id="example" class="table table-striped table-bordered" style="width:100%">
						<thead>
							<tr>
								<th title="Serial No">Sl</th>
								<th title="Employe Name">Employe Name</th>
								<th title="Employe Id">Employe Id</th>
								<th title="Added Time">Added Time</th>
								<th>Control</th>
							</tr>
						</thead>
						<tbody>
						
						<?php
						$i = 0;
						if($employe){
							foreach($employe as $value){
								$i++;
						?>
						
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $value['employName'];?></td>
								<td><?php echo $value['employId'];?></td>
								<td><?php echo $help->Formate_2($value['addedTime']);?></td>
								<td>
									<a href="" class="btn btn-default btn-sm" title="Edit Visitor Type" data-toggle="modal" data-target=".e<?php echo  $value['id'];?>">
										<i class="fas fa-pen-square"></i>
									</a>
									<a href="" class="btn btn-default btn-sm" title="Delete Visitor Type" data-toggle="modal" data-target=".d<?php echo  $value['id'];?>">
										<i class="fas fa-trash-alt"></i>
									</a>
					
								</td>
								
								
								
<div class="modal fade e<?php echo  $value['id'];?>">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-center" id="exampleModalLabel"></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">



<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
<h2 class="col-sm-12 text-center">Edit Employe List</h2><br/>
<div class="clearfix"></div>
<div class="col-sm-12 col-md-12 text-left">


<div class="form-group row">
&nbsp;
</div>

<form method="post" action="">
	
<div class="form-group row">
<label for="1" class="col-sm-4 col-form-label text-right"><b>Employe Name</b></label>
<div class="col-sm-8">

<input type="text" class="form-control" id="1" value="<?php echo $value['employName'];?>" name="empName">

</div>
</div>

<div class="form-group row">
<label for="2" class="col-sm-4 col-form-label text-right"><b>Employe Id</b></label>
<div class="col-sm-8">

<input type="hidden" name="id" value="<?php echo $value['id'];?>"/>
<input type="text" class="form-control" id="2" value="<?php echo $value['employId'];?>" name="empId">

</div>
</div>



<div class="form-group">
<label class="control-label col-sm-4" for="email"></label>
<div class="col-sm-8">
<button type="submit" name="upEmploye" class="btn btn-success"> Update</button>
</div>
</div>
</form>
</div>
</div>







				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</div>





								
<div class="modal fade d<?php echo  $value['id'];?>">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<div class="modal-content">
				
				<div class="modal-body text-center">



<h1 style="font-size: 70px;"><i class="fas fa-question-circle"></i></h1>
<p>Are you sure to delete ? </p>

<form action="" method="post">
	<input type="hidden" name="id" value="<?php echo $value['id'];?>"/>
<button type="submit" name="delEmploye" class="btn btn-success btn-sm">
	<i class="fas fa-check-circle"></i> YES
</button>
<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
	<i class="fas fa-times-circle"></i> NO
</button>
</form>

<br/><br/>
				</div>
			</div>
		</div>
	</div>
</div>





<?php }} ?>

							</tr>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>



<?php include "dinc/footer.php" ;?>	