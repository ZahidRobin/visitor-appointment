$(function(){
    $('[data-toggle="tooltip"]').tooltip();
    $(".side-nav .collapse").on("hide.bs.collapse", function() {                   
        $(this).prev().find(".fa").eq(1).removeClass("fa-angle-right").addClass("fa-angle-down");
    });
    $('.side-nav .collapse').on("show.bs.collapse", function() {                        
        $(this).prev().find(".fa").eq(1).removeClass("fa-angle-down").addClass("fa-angle-right");        
    });
})    
    
    
    
      	$(document).ready(function() {
		$('#example').DataTable();
	}); 
	
	
	
	
	
	   $(document).ready(function() {
		$( "#datepicker" ).datepicker({
				showOtherMonths: true,
				selectOtherMonths: false,
				changeMonth:true,
				changeYear:true,
				dateFormat: "yy-mm-dd",
				
			});
		});
	
	   $(document).ready(function() {
		$( "#datepicker1" ).datepicker({
				showOtherMonths: true,
				selectOtherMonths: false,
				changeMonth:true,
				changeYear:true,
				dateFormat: "yy-mm-dd",
				
			});
		});
	
	   $(document).ready(function() {
		$( "#datepicker2" ).datepicker({
				showOtherMonths: true,
				selectOtherMonths: false,
				changeMonth:true,
				changeYear:true,
				dateFormat: "yy-mm-dd",
				
			});
		});
	
	
	$(window).on('load',function(){
        $('#myModal').modal('show');
        
    });
	
	

	
	
	
	
	
	