<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/registrationFunction.php";
   include "php/classes/appointmentFunction.php";
   $appFunction = new appointmentFunctiuon();
   $regFunction = new Registration();
   
   if($_SERVER['REQUEST_METHOD'] == "POST"){
   	$appCreate = $appFunction->appointmentCreate($_POST);
   }
   
   
   $vType = $regFunction->selectVtype();
   ?>
<br/><br/>
<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
   <h2 class="col-sm-12">Create Visitor Appointment</h2>
   <br/><br/><br/>
   <div class="clearfix"></div>
   <div class="col-md-2"></div>
   <div class="col-sm-12 col-md-8 text-left">
      <form action="" method="post"  class="form-horizontal" >
         <fieldset>
            <?php
               if(isset($appCreate)){
               	echo $appCreate ;
               }
               ?>
            <div class="form-group row">
               <label for="vName" class="col-sm-3 col-form-label text-left"><b>Visitor Name</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" name="vName"  id="vName" placeholder="Visitor Name" value="<?php if(isset($_POST['vName'])){echo $_POST['vName'] ;} ;?>">
               </div>
            </div>
            <div class="col-sm-12"  id="show">
               </table>
            </div>
            <div class="form-group row">
               <label for="vContact" class="col-sm-3 col-form-label text-left"><b>Visitor Contact No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" name="vContact" id="vContact" placeholder="Visitor Contact No" value="<?php if(isset($_POST['vContact'])){echo $_POST['vContact'] ;} ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="vNID" class="col-sm-3 col-form-label text-left"><b>NID/Passport</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" name="vNID" id="vNID" placeholder="Visitor NID/Passport" value="<?php if(isset($_POST['vNID'])){echo $_POST['vNID'] ;} ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="vCOmpany" class="col-sm-3 col-form-label text-left"><b>Company</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" name="vCOmpany" id="vCOmpany" placeholder="Company" value="<?php if(isset($_POST['vCOmpany'])){echo $_POST['vCOmpany'] ;} ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="vType" class="col-sm-3 col-form-label text-left"><b>Visitor Type</b></label>
               <div class="col-sm-9">
                  <select name="vType" class="form-control" id="vType">
                     <option value="">- Select visitor Type -</option>
                     <?php 
                        if($vType){
                        	foreach($vType as $value){
                        	
                        		?>
                     <option <?php
                           if(isset($_POST['vType']) AND $_POST['vType'] 
                           == $value['visitortype']){
                           	echo 'selected="selected"';
                           }
                           ?> value="<?php echo $value['visitortype'] ;?>"><?php echo $value['visitortype'] ;?></option>
                     <?php }} ?>
                  </select>
               </div>
            </div>
            <div class="form-group row">
               <label for="datepicker" class="col-sm-3 col-form-label text-left"><b>Visiting Date</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" name="visitingDate" id="datepicker" placeholder="Visiting Date" value="<?php if(isset($_POST['visitingDate'])){echo $_POST['visitingDate'] ;} ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="6" class="col-sm-3 col-form-label text-left"><b>Appointment</b></label>
               <div class="form-check">
                  <input class="form-check-input app" type="radio" name="exampleRadios" id="no" value="me" 
                     checked="checked" >
                  <label class="form-check-label" for="no" style="cursor: pointer;">
                  Me
                  </label>
               </div>
               &nbsp;&nbsp;
               <div class="form-check">
                  <input class="form-check-input app" type="radio" name="exampleRadios" id="yes" value="another">
                  <label class="form-check-label" for="yes" style="cursor: pointer;">
                  Another
                  </label>
               </div>
            </div>
            <div class="form-group row" id="metting_with">
               <label for="7" class="col-sm-3 col-form-label text-left"><b>Metting With</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control colo" name="meetWith" id="7" placeholder="His/Her Name" value="<?php if(isset($_POST['meetWith'])){echo $_POST['meetWith'] ;} ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="inputPassword" class="col-sm-3 col-form-label text-left"><b></b></label>
               <div class="col-sm-9">
                  <button type="submit" class="btn btn-dark">Create</button>
               </div>
            </div>
         </fieldset>
      </form>
   </div>
</div>
<br/><br/>
<?php include "inc/footer.php"; ?>