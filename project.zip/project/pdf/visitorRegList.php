<?php
include "../php/lib/appSession.php";
Session ::checkappSession();
include "fpdf/fpdf.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";
include "../php/classes/registrationFunction.php";

$db   = new DataBase();
$help = new Helpers();
$regFunction = new Registration();
$regInfo     = $regFunction->getRegistrationList();

$pdf = new FPDF();
$pdf->SetAutoPageBreak(TRUE);
$pdf->AddPage('L','A4');



$pdf->SetAuthor('Smart Corporation | Eeastern Plaza | PRANTO');
$pdf->SetTitle($help->title().' - '.TITLE);


/*Store Info*/


$pdf->SetY(10);
$pdf->SetX(95);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 20);
$pdf->Cell(100, 10, 'Smart Corporation', 0, 0, 'C');
$pdf->Ln(10);

$pdf->SetY(20);
$pdf->SetX(95);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 16);
$pdf->Cell(100, 10, 'Visitor Registration List', 0, 0, 'C');
$pdf->Ln(10);



$pdf->SetFillColor(232, 232, 232);
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetY(33);
$pdf->SetX(8);
$pdf->Cell(15, 7, 'SL', 1, 0, 'C', 1);
$pdf->Cell(50, 7, 'Visitor Name', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Visiting NID', 1, 0, 'C', 1);
$pdf->Cell(50, 7, 'Visitor Contact No', 1, 0, 'C', 1);
$pdf->Cell(45, 7, 'Company', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Visitor Type', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Visitor Creator', 1, 0, 'C', 1);
$pdf->Ln(7);

$i = 0 ;
if($regInfo){
	foreach($regInfo as $value){
		$i++;


$pdf->SetX(8);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(15, 7, $i, 1, 0, 'C');
$pdf->Cell(50, 7, $value['visitorName'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['visitorNidPassport'], 1, 0, 'C');
$pdf->Cell(50, 7, $value['visitorContactNo'], 1, 0, 'C');
$pdf->Cell(45, 7, $value['visitorCompany'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['visitorType'], 1, 0, 'C');
$pdf->Cell(40, 7, Session::get('empName'), 1, 0, 'C');
$pdf->Ln(7);

	}
 }
	
$pdf->Output();

?>