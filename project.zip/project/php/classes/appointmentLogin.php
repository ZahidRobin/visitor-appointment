<?php

class appLogin {
	
	public $db;
	public $help;
	
	public function __construct() {
		
		$this->db   = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function getAppLogin($appId){
		
		return $this->loginInfo($appId);
	}
	
	private function loginInfo($appId){
		
		$appId = mysqli_real_escape_string($this->db->link,$appId);
		$appId = $this->help->validation($appId);
		
		if(empty($appId)){
			$msg = '<div class="alert alert-danger"><b><i class="ace-icon fa fa-times-circle fa-1x">
					</i></b>&nbsp;Filed must not be empty !<br /></div>';
			return $msg;
		}else{
			
			$select = "SELECT * FROM `tbl_employe` WHERE `employId` = '$appId' LIMIT 1";
			$sql    = $this->db->select($select);
			
			if($sql == TRUE){
				
				$logininfo = $sql->fetch_assoc();
				
				if($logininfo){
					
					Session :: set('loginApp',TRUE);
					Session :: set('empId',$logininfo['id']);
					Session :: set('empName',$logininfo['employName']);
					Session :: set('empId',$logininfo['employId']);
					Session ::set("loginMsg",'<div id="myModal" class="modal fade"  role="dialog">
											  <div class="modal-dialog modal-sm" >
											  <div class="modal-content">
			                                  <div class="modal-body text-center" >
				                              <p class="h3 green">
				                              <i class="fa fa-5x fa fa-check-circle"></i></p>
				                              <p class="h4">Success !</p>
				                              <b>Mr/Mrs/Miss/. '.$logininfo['employName'].'</b>
				                              <p>Your Login Successful</p>
				                              <p></p>
				                              <br/>
			                                  </div>
		                                      </div>
	                                          </div>
											  </div>');
					header("Location:index.php");
				}
				
			}else{
					
					$msg = '<div class="alert alert-danger"><b><i class="ace-icon fa fa-times-circle fa-1x"></i> Error !</b>&nbsp;Empolye Id is not correct !<br /></div>';
					return $msg;
					
				}
						
		}
		
		
	}
	
}     
        
                                                                                        
?>