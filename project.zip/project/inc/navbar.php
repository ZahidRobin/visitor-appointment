<?php 
   if(isset($_GET['action'])){
   	Session :: destroy();
   }
   
   date_default_timezone_set('Asia/Dhaka');
   $date      = date("Y-m-d");
   $empId     = Session :: get('empId');
   
   $selectApp = "SELECT * FROM `tbl_appointment` WHERE `appointmrntCreator` = '$empId' 
   			   AND visitingDate = '$date' AND checkOut = ''  ORDER BY id DESC";
   			   
   $sql       = $db->select($selectApp);
   
   ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
   <div class="container">
      <a class="navbar-brand" href="index.php"><i class="fas fa-th"></i> Smart Corporation</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
         <ul class="navbar-nav ml-auto">
            <li class="nav-item <?php if($current == "index"){echo "active";}?>">
               <a class="nav-link" href="index.php" title="Go to home page"><i class="fas fa-home"></i> Home</a>
            </li>
            <li class="nav-item <?php if($current == "registration"){echo "active";}?>">
               <a class="nav-link" href="registration.php" title="Creator Visitor List"><i class="fas fa-registered"></i> Registration</a>
            </li>
            <li class="nav-item <?php if($current == "createAppointment"){echo "active";}?>">
               <a class="nav-link" href="createAppointment.php" title="Creator Visitor Appointment"><i class="fas fa-pen-square"></i> Appointment</a>
            </li>
            <li class="nav-item <?php if($current == "visitorList"){echo "active";}?>">
               <a class="nav-link" href="visitorList.php" title="Go to visitor list"><i class="fas fa-list-alt"></i> 
               Visitor List <sup style="font-size: 20px;"><?php if($sql == TRUE){echo $count = $sql->num_rows;} ?></sup>
               </a>
            </li>
            <li class="nav-item dropdown <?php if($current == "registrationList"){echo "active";}?>">
               <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
               <i class="fas fa-external-link-square-alt"></i> Extra
               </a>
               <div class="dropdown-menu dropdown-menu-right" style="background-color: #343A40;">
                  <a class="dropdown-item  <?php if($current == "registrationList"){echo "active";}?>" href="registrationList.php" >Visitor Registration Profile List</a>
                  <a class="dropdown-item" href="pdf/visitorRegList.php" >Print Visitor Registration Profile List</a>
               </div>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="?action=<?php echo Session::get('empId'); ?>" title="Logout to this account"><i class="fas fa-sign-out-alt"></i> Logout
               </a>
            </li>
         </ul>
      </div>
   </div>
</nav>