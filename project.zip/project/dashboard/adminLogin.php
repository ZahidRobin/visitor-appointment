<?php

include "../php/lib/session.php";
Session ::checkLogin();
include "../php/classes/adminLogin.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";

$adminLogin = new adminLogin();

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['adminLogin'])){
	$adminEmail    = $_POST['adminEmail'];
	$adminPassword = md5($_POST['adminPassword']);
	
	$adminLoginCheck = $adminLogin->getAdminLogin($adminEmail,$adminPassword);
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin Login - Samart Corporation</title>
		<link rel="shortcut icon" href="../asset/facicon.png"/>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">	
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js"></script>
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
		<br/><br/><br/><br/><br/><br/><br/><br/>
		<div class="col-sm-4 col-sm-offset-4">
			<div class="panel panel-default">
				<div class="panel-heading text-center"><b><i class="fas fa-unlock-alt"></i> Admin Login</b></div>
				<div class="panel-body">
					<form class="form-horizontal" action="" method="post">
						<?php
						
							if(isset($adminLoginCheck)){
								echo $adminLoginCheck ;
							}
						
				            $ChagePassword = Session :: get('ChagePassword');
				            if(isset($ChagePassword)){
				            	echo $ChagePassword;
				            }
				            Session :: set('ChagePassword',NULL);
				            
			            ?>
						
						<div class="form-group">
							<div class="col-sm-12">
								<input type="email" class="form-control" id="email" placeholder="Admin Email" name="adminEmail">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="password" class="form-control" id="email" placeholder="Admin Password" name="adminPassword">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<button type="submit" name="adminLogin" class="btn btn-default btn-block"><i class="fas fa-unlock-alt"></i> Login</button>
							</div>
						</div>
						
							
						<a class="btn btn-link" href="adminRegistration.php">Create an account .</a>
						
						
					</form>
					
				</div>
			</div>
		</div>
	</body>
</html>	
	
	
	
	
	
	
	
	
