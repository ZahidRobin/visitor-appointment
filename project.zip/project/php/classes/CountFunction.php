<?php
class Count {
	
	public $db;
	public $help;
	
	public function __construct() {
		
		$this->db   = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function appointmentCount(){
		
		$selecApp = "SELECT * FROM `tbl_appointment` WHERE `checkIn` = '' AND `checkOut` = ''";
		$SqlApp   = $this->db->select($selecApp);
		if($SqlApp){
			$result   = $SqlApp->num_rows;
			return $result;
		}else{
			$result = '0';
			return $result;
		}
	}
	
	public function CheckinCount(){
		
		date_default_timezone_set('Asia/Dhaka');
		$date         = date("Y-m-d");
		$selecCheckin = "SELECT * FROM `tbl_appointment` WHERE `checkIn` != '' AND 
						 `visitingDate` = '$date'";
						 
		$SqlCheckin   = $this->db->select($selecCheckin);
		if($SqlCheckin){
			$result   = $SqlCheckin->num_rows;
			return $result;
		}else{
			$result = '0';
			return $result;
		}
		
	}
	
	public function CheckOutCount(){
		
		date_default_timezone_set('Asia/Dhaka');
		$date          = date("Y-m-d");
		$selecCheckOut = "SELECT * FROM `tbl_appointment` WHERE `checkIn` != '' AND `checkOut` != '' AND
						 `visitingDate` = '$date'";
		
		$SqlCheckOut   = $this->db->select($selecCheckOut);
		if($SqlCheckOut){
			$result   = $SqlCheckOut->num_rows;
			return $result;
		}else{
			$result = '0';
			return $result;
		}
		
	}
	
	public function visitorInFactory(){
		
		$selecvis = "SELECT * FROM `tbl_appointment` WHERE `checkIn` != '' AND `checkOut` = ''";
		$Sqlvis   = $this->db->select($selecvis);
		if($Sqlvis){
			$result   = $Sqlvis->num_rows;
			return $result;
		}else{
			$result = '0';
			return $result;
		}
		
	}
	
	public function deletedVisitor(){
		
		$selecDvis = "SELECT * FROM `tbl_registration` WHERE `deleted` = '1';";
		$SqlDvis   = $this->db->select($selecDvis);
		if($SqlDvis){
			$result   = $SqlDvis->num_rows;
			return $result;
		}else{
			$result = '0';
			return $result;
		}
		
	}
}
?>