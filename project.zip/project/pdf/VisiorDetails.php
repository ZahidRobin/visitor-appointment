<?php
include "fpdf/fpdf.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";
include "../php/classes/adminFunction.php";
$db         = new DataBase();
$help       = new Helpers();
$admin_Info = new adminInfo();

if(isset($_GET['id'])){
	$id   = $_GET['id'];
}else{
	header("Location:../dashboard/index.php");
}
$getAppdetails = $admin_Info->getAppDetails($id);


if($getAppdetails['checkIn'] == ""){
	$check = 'NO';
}else{
	$check = 'YES';
}



if($getAppdetails['mettingStart'] == ""){
	$meet = 'NO';
}else{
	$meet = 'YES';
}

if($getAppdetails['checkOut'] == ""){
	$ckut = 'NO';
}else{
	$ckut = 'YES';
}


$pdf = new FPDF('L','mm', array(160, 115)); 

$pdf->Cell(2);
$pdf->AddPage();
$pdf->SetAuthor('Smart Corporsation | Eeastern Plaza | Pranto');
$pdf->SetTitle('Smart Corporsation | V.2.0');

//$pdf->Rect(5, 86, 90, 56, 'D');//this line for boarder
//$pdf->Rect(6, 87, 88, 54, 'D');//this line for boarder

$pdf->SetFont("Arial","","");
$pdf->Cell(100,15,'',0,0,'C',0);
$image1 = "../captureImge/".$getAppdetails['id'].".jpg";
$pdf->Cell( 0, 0, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 40,35), 0, 0, 'C', false );

$pdf->Ln(1);
$pdf->SetFont("Arial","B","24");
$pdf->Cell(17,5,'',0,0,'L',0);
$pdf->Cell(20,5,'Visitor Details',0,0,'C',0);
$pdf->Ln(7);


$pdf->SetFont("Arial","","13");
$pdf->Cell(17,5,'',0,0,'L',0);
$pdf->Cell(20,5,'Smart Corporation, Dhaka',0,0,'C',0);
$pdf->Ln(7);


$pdf->Cell(1,3,'',0,0,'C',0);
$pdf->Cell(75,0,'','B',0,'C',0);
$pdf->Ln(1);
$pdf->Cell(1,3,'',0,0,'C',0);
$pdf->Cell(75,0,'','B',0,'C',0);


/*$pdf->Cell(75,3,'','B',0,'C',0);
$pdf->Cell(75,5,'','B',0,'C',0);*/

/*$pdf->Cell(1,5,'',0,0,'C',0);
$pdf->Cell(130,0,'','B',0,'C',0);
$pdf->Ln(1);
$pdf->Cell(1,5,'',0,0,'C',0);
$pdf->Cell(130,0,'','B',0,'C',0);*/


$pdf->Cell(15,5,'',0,0,'C',0);
$pdf->SetFont("Arial","","11");
$pdf->Ln(3);
$pdf->Cell(30,5,'Visitor Id No ',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['id'],0,0,'L',0);
$pdf->Ln(5);


$pdf->Cell(30,5,'Visiting Date ',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$help->Formate($getAppdetails['visitingDate']),0,0,'L',0);



$pdf->Ln(5);
$pdf->Cell(30,5,'Name ',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['visitorName'],0,0,'L',0);



$pdf->Ln(5);
$pdf->Cell(30,5,'Mobile ',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['visitorReg_phoneNum'],0,0,'L',0);




$pdf->Ln(5);
$pdf->Cell(30,5,'NID/Passport ',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['visitorNID'],0,0,'L',0);



$pdf->Ln(5);

$pdf->Cell(30,5,'From',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['visitorCompany'],0,0,'L',0);


$pdf->Ln(5);

$pdf->Cell(30,5,'To Meet',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['appointmentWith'],0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Check In',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$check,0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Check In Time',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['checkInTime'],0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Meeting Start',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$meet,0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Meeting Start Time',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['meeting_start_time'],0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Check Out',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$ckut,0,0,'L',0);

$pdf->Ln(5);

$pdf->Cell(30,5,'Check Out Time',0,0,'L',0);
$pdf->Cell(12,5,':',0,0,'C',0);
$pdf->Cell(60,5,$getAppdetails['checkOutTime'],0,0,'L',0);

$pdf->Ln(5);


$pdf->Output();


?>











