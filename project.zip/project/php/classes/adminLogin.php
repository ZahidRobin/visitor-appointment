<?php
class adminLogin {
	
	
	public $db;
	public $help;
	
	
	public function __construct() {
		
		$this->db   = new DataBase();
		$this->help = new Helpers();
		
	}
	
	public function getAdminLogin($adminEmail,$adminPassword){
		return $this->adminLoginInfo($adminEmail,$adminPassword);
	}
	
	private function adminLoginInfo($adminEmail,$adminPassword){
		
			$adminEmail    = mysqli_escape_string($this->db->link,$adminEmail);
			$adminPassword = mysqli_escape_string($this->db->link,$adminPassword);
			
			$adminEmail    = $this->help->validation($adminEmail);
			$adminPassword = $this->help->validation($adminPassword);
			
			if(empty($adminEmail) OR empty($adminPassword)){
				
				$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Field must not be empty !
				</div>
				</div>
				</div>';
				
				return $msg ;
			}else{
				
				$select = "SELECT * FROM `tbl_admin` WHERE 
						  `adminEmail`= '$adminEmail' AND `adminPassword` = '$adminPassword' LIMIT 1;";
				$sql    = $this->db->select($select);
								
				if($sql == TRUE){
					
					$resultAdminLogin = $sql->fetch_assoc();
					
					if($resultAdminLogin['permission'] > '0' ){
						
						Session :: set("login",TRUE);
						Session :: set("adminId",$resultAdminLogin['id']);
						Session :: set("adminName",$resultAdminLogin['adminName']);
						Session :: set("adminEmail",$resultAdminLogin['adminEmail']);
						Session :: set("permite",$resultAdminLogin['permission']);
						
						header("Location:index.php");
					}else{
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Super Admin not permite you to Login !
					</div>
					</div>
					</div>';
					
					return $msg ;
					
					}
					
					
				}else{
					
					$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> User name Or Password is Invalid !
					</div>
					</div>
					</div>';
					
					return $msg ;
					
				}
				
				
			}

	}
	
	
	public function regAdmin($checkInfo){
		
		$adminName     = mysqli_real_escape_string($this->db->link,$checkInfo['adminName']);
		$adminEmail    = mysqli_real_escape_string($this->db->link,$checkInfo['adminEmail']);
		$adminPassword = mysqli_real_escape_string($this->db->link,$checkInfo['adminPassword']);
		
		$adminName     = $this->help->validation($adminName);
		$adminEmail    = $this->help->validation($adminEmail);
		$adminPassword = $this->help->validation($adminPassword);
		
		$checkMail     = "SELECT `adminEmail` FROM `tbl_admin` WHERE `adminEmail` = '$adminEmail'";
		$CheckSql      = $this->db->select($checkMail);
		
		
		if($adminName == '' OR $adminEmail == '' OR $adminPassword == ''){
			
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Field must not be empty !
				</div>
				</div>
				</div>';
				
			return $msg ;
			
		}elseif($CheckSql == TRUE){
			
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> This email hasbeen already exist !
				</div>
				</div>
				</div>';
				
			return $msg ;
			
		}else if(filter_var($adminEmail,FILTER_VALIDATE_EMAIL) === FALSE){
			
			$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> This email is invalid !
				</div>
				</div>
				</div>';
				
			return $msg ;
		 	
		 }elseif(strlen($adminPassword) < 8){
		 
		 	$msg = '<div class="form-group">
				<div class="col-sm-12">
				<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<strong>Error !</strong> Password is too short !
				</div>
				</div>
				</div>';
				
			return $msg ;
		 	
		 	
		 }else{
		 	
		 	$adminPassword = md5($adminPassword);
		 	$insartAdmin   = "INSERT INTO `tbl_admin`(`adminName`, `adminEmail`, `adminPassword`) 
		 					  VALUES ('$adminName','$adminEmail','$adminPassword')";
		 	
		 	$sqlInsart     = $this->db->insart($insartAdmin);
		 	
		 	if($sqlInsart){
			 	
				 $msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-success alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Success !</strong> '.$adminName.' Your Registration Successfull and Please wait for admin permission!
					</div>
					</div>
					</div>';
					
				return $msg ;
			 	
			 }
		 	
		 }
		
	}
	
	public function adminUser(){
		
		$selectAdmin = "SELECT * FROM `tbl_admin` WHERE `permission` < '4'";
		$sqlAdmin    = $this->db->select($selectAdmin);
		
		if($sqlAdmin){
			while($readAdmin = $sqlAdmin->fetch_assoc()){
				
				$resultAdmin[] = $readAdmin;
				
			}
			return $resultAdmin ;
		}
		
	}
	
	public function roleSet($id,$role){
		
		if($role == ''){
			
			$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Please select user role !
					</div>
					</div>
					</div>';
			return $msg;
		}
		
		$roleSet = "UPDATE `tbl_admin` SET `permission`='$role' WHERE `id` = '$id'";
		$sqlRole = $this->db->update($roleSet);
		
		if($sqlRole){
			
			$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-success alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong> Success !</strong> Role Created Successfull !
					</div>
					</div>
					</div>';
			return $msg;
			
		}else{
			
			$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Role not Created !
					</div>
					</div>
					</div>';
			return $msg;
		}
		
	}
	
	public function checkPassword($id){
		$checkPassword = "SELECT * FROM `tbl_admin` WHERE `id` = '$id'";
		$sqlCheckPass  = $this->db->select($checkPassword);
		
		if($sqlCheckPass){
			$resultPass = $sqlCheckPass->fetch_assoc();
			return $resultPass;
		}
		
	}
	
	
	public function changePassword($password){
		
		$id              = Session :: get('adminId');
		$currentPassword = mysqli_real_escape_string($this->db->link,$password['currPassword']);
		$newPassword     = mysqli_real_escape_string($this->db->link,$password['newPassword']);
		$reNewPassword   = mysqli_real_escape_string($this->db->link,$password['reNewPassword']);
		
		$currentPassword = $this->help->validation($currentPassword);
		$newPassword     = $this->help->validation($newPassword);
		$reNewPassword   = $this->help->validation($reNewPassword);
		
		$checkPass       = $this->checkPassword($id);
		$dbpassWord      = $checkPass['adminPassword'];
		$currentPassword = md5($currentPassword);
		
		if($currentPassword == "" OR $newPassword == "" OR $reNewPassword == ""){
			
			$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Filed must not be empty !
					</div>
					</div>
					</div>';
			return $msg;
			
		}elseif($currentPassword != $dbpassWord){
			  	
			 $msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Current Password is not match !
					</div>
					</div>
					</div>';
			 return $msg; 	
			  	
		}elseif($newPassword != $reNewPassword){
			
			$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> New Password and Re-type new Password is not match !
					</div>
					</div>
					</div>';
			 return $msg; 
			
			
		}else{
			
			$reNewPassword  = md5($reNewPassword);
			$changePassword = "UPDATE `tbl_admin` 
							   SET 
							   `adminPassword` = '$reNewPassword' 
							   WHERE `id` = '$id'";
			$sqlChangePass  = $this->db->update($changePassword);
			
			if($sqlChangePass){
				
				$msg = '<div id="myModal" class="modal fade" data-backdrop="static" role="dialog">
								  <div class="modal-dialog modal-sm" >
								  <div class="modal-content">
                                  <div class="modal-body text-center" >
	                              <p class="h3 green">
	                              <i class="fa fa-5x fa fa-check-circle"></i></p>
	                              <p class="h4">Success !</p>
	                              <p>Password Change successfull.</p>
	                              <p>Please Click "OK" and Re-Login</p>
	                              <a href=?action="'.$id.'" class="btn btn-default btn-xs btn-block">OK</a>
	                              <p></p>
	                              <br/>
                                  </div>
                                  </div>
                                  </div>
								  </div>';
				return $msg;
				
			}else{
				
				$msg = '<div class="form-group">
					<div class="col-sm-12">
					<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Error !</strong> Password not change !
					</div>
					</div>
					</div>';
				 return $msg; 
			}
			
		}

		
	}
	
}
?>

