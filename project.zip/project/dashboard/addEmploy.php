<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/adminFunction.php";
$admin_Info = new adminInfo();

if($_SERVER['REQUEST_METHOD'] == "POST"){
	
	$addEmployeInfo = $admin_Info->addEmploye($_POST);
	
}
?>


	<br/>					
	<div class="col-sm-12">
		<div class="col-sm-10 col-sm-offset-1">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b> Add Employ </b></h4></div>
				<div class="panel-body">
				
				
<form class="form-horizontal" action="" method="post">
	<?php
	if(isset($addEmployeInfo)){
		echo $addEmployeInfo;
	}
	?>

	<div class="form-group">
		<label class="control-label col-sm-2" for="employe">Employ Name:</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="employe" placeholder="Employ Name" name="employe">
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="employeId">Employ ID:</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="employeId" placeholder="Employ ID" name="employeId">
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="email"></label>
		<div class="col-sm-10">
			<button type="submit" class="btn btn-success"> Add</button>
			<a href="employList.php" class="btn btn-info"> View</a>
		</div>
	</div>
</form>
				
				
					
				</div>
			</div>
		</div>
	</div>



<?php include "dinc/footer.php" ;?>	