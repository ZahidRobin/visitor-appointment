<?php
include "../php/lib/session.php";
Session :: checkSession();
include "fpdf/fpdf.php";
include "../php/config/config.php";
include "../php/lib/DB.php";
include "../php/lib/helpers.php";
include "../php/classes/adminFunction.php";

$db   = new DataBase();
$help = new Helpers();
$admin_Info = new adminInfo();


$pdf = new FPDF();
$pdf->SetAutoPageBreak(TRUE);
$pdf->AddPage('L','A4');



$pdf->SetAuthor('Smart Corporation | Eeastern Plaza | PRANTO');
$pdf->SetTitle($help->title().' - '.TITLE);


/*Store Info*/


$pdf->SetY(10);
$pdf->SetX(95);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 20);
$pdf->Cell(100, 10, 'Smart Corporation', 0, 0, 'C');
$pdf->Ln(10);

$pdf->SetY(20);
$pdf->SetX(95);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 16);
$pdf->Cell(100, 10, 'Visitor Appointment List', 0, 0, 'C');
$pdf->Ln(10);



$pdf->SetFillColor(232, 232, 232);
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetY(33);
$pdf->SetX(8);
$pdf->Cell(15, 7, 'SL', 1, 0, 'C', 1);
$pdf->Cell(35, 7, 'Visitor Name', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Visiting NID', 1, 0, 'C', 1);
$pdf->Cell(35, 7, 'Visitor Contact', 1, 0, 'C', 1);
$pdf->Cell(30, 7, 'Visitor Type', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Appointment With', 1, 0, 'C', 1);
$pdf->Cell(40, 7, 'Visitor Creator', 1, 0, 'C', 1);
$pdf->Cell(45, 7, 'Visiting Date', 1, 0, 'C', 1);
$pdf->Ln(7);

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['dayWise'])){

		$dayWisedate = $_POST['dayWisedate'];
		$dayWiseApp  = $admin_Info->appDaywise($dayWisedate);

		$i = 0 ;
		if($dayWiseApp){
			foreach($dayWiseApp as $value){
				$i++;


$pdf->SetX(8);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(15, 7, $i, 1, 0, 'C');
$pdf->Cell(35, 7, $value['visitorName'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['visitorNID'], 1, 0, 'C');
$pdf->Cell(35, 7, $value['visitorReg_phoneNum'], 1, 0, 'C');
$pdf->Cell(30, 7, $value['visitorType'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['appointmentWith'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['appointmrntCreator'], 1, 0, 'C');
$pdf->Cell(45, 7, $help->Formate($value['visitingDate']), 1, 0, 'C');
$pdf->Ln(7);

	}
  }else{
  	
$pdf->SetX(8);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(280, 7, 'No appointment available in this date', 1, 0, 'C');
$pdf->Ln(7);
  	
  	
  }
}
	
	

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['dayTodayWise'])){

		$srtDate   = $_POST['srtDate'];
		$endDate   = $_POST['endDate'];
		$dayTOday  = $admin_Info->appDayToDaywise($srtDate,$endDate);

		$i = 0 ;
		if($dayTOday){
			foreach($dayTOday as $value){
				$i++;


$pdf->SetX(8);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(15, 7, $i, 1, 0, 'C');
$pdf->Cell(35, 7, $value['visitorName'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['visitorNID'], 1, 0, 'C');
$pdf->Cell(35, 7, $value['visitorReg_phoneNum'], 1, 0, 'C');
$pdf->Cell(30, 7, $value['visitorType'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['appointmentWith'], 1, 0, 'C');
$pdf->Cell(40, 7, $value['appointmrntCreator'], 1, 0, 'C');
$pdf->Cell(45, 7, $help->Formate($value['visitingDate']), 1, 0, 'C');
$pdf->Ln(7);

	}
  }else{
  	
$pdf->SetX(8);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(280, 7, 'No appointment available in this date', 1, 0, 'C');
$pdf->Ln(7);
  	
  	
  }
}
	
	
	
	
	
$pdf->Output();

?>