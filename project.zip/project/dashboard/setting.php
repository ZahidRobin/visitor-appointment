<?php include "dinc/header.php" ;?>
<?php include "dinc/sidebar.php" ;?>
<?php
include "../php/classes/adminLogin.php";
$adminLogin = new adminLogin();

if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['crtRole'])){
		
		$id      = $_POST['id'];
		$role    = $_POST['role'];
		$roleSet = $adminLogin->roleSet($id,$role);
}

$adminUser  = $adminLogin->adminUser();
?>
<?php					
	if(Session:: get('permite') == '4'){
?>

	<br/>	
	<div class="col-sm-12">
		<div class="col-sm-12">

			<div class="panel panel-default">
				<div class="panel-heading text-center"><h4><b>Admin User Request</b></h4></div>
				<div class="panel-body">
				
				<?php if(isset($roleSet)){ echo $roleSet; } ?>
				
				
					<table id="example" class="table table-striped table-bordered" style="width:100%">
						<thead>
							<tr>
								<th title="Serial No">Sl</th>
								<th title="Admin Name">Name</th>
								<th title="Admin Email">Email</th>
								<th title="Admin Reg Time">Time</th>
								<th title="Permission">Permission</th>
								<th>Control</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
						$i = 0;
						if($adminUser){
							foreach($adminUser as $value){
								$i++;
						
						?>
						
							<tr>
								<td><?php echo $i ;?></td>
								<td><?php echo $value['adminName'] ;?></td>
								<td><?php echo $value['adminEmail'] ;?></td>
								<td><?php echo $help->Formate_2($value['adminRegTime']) ;?></td>
								<td>
								
								<?php if($value['permission'] == "3"){ ?>
									<label class="label label-success">Admin User</label> 
								<?php } ?>
								
								
								<?php if($value['permission'] == "2"){ ?>
									<label class="label label-primary">Editor User</label> 
								<?php } ?>
								
								
								<?php if($value['permission'] == "1"){ ?>
									<label class="label label-info">Authenticator User</label> 
								<?php } ?>
								
								</td>
								<td>
								
								
								
<div class="col-sm-10">
<form action="" method="post">
	<div class="input-group">
		<input type="hidden" name="id" value="<?php echo $value['id'] ;?>"/>
		<select class="form-control" name="role">
		
			<option value="">- Set User Role -</option>
			<option <?php if($value['permission'] == '3'){echo 'selected="selected"';}?> value="3">
				Admin
			</option>
			<option <?php if($value['permission'] == '2'){echo 'selected="selected"';}?> value="2">
				Editor
			</option>
			<option <?php if($value['permission'] == '1'){echo 'selected="selected"';}?> value="1">
				Authenticator
			</option>
			
		</select>
		<span class="input-group-btn">
		
			<button class="btn btn-success" type="submit" name="crtRole" >
				<i class="fas fa-check-square"></i>
			</button>
			
		</span>
	</div>
</form>
</div>
									
									
									
									<a href="" class="btn btn-danger" title="Check in">
										<i class="fas fa-trash-alt"></i>
									</a>
					
								</td>

							</tr>
						<?php
							}}
						?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

<?php } ?>

<?php include "dinc/footer.php" ;?>	