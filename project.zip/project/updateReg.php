<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/registrationFunction.php";
   $regFunction = new Registration();
   
   if(isset($_GET['id'])){
   	$id = $_GET['id'];
   }else{
   	header("Location:registrationList.php");
   }
   if($_SERVER['REQUEST_METHOD'] == "POST"){
   	$updateRegInfo = $regFunction->updateFunction($_POST,$_FILES);
   }
   
   $getReginfo  = $regFunction->upRegInfo($id);
   $vType 		 = $regFunction->selectVtype();
   ?>
<br/><br/><br/>
<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
   <h2 class="col-sm-12">Update Visitor Registration Profile</h2>
   <br/><br/><br/>
   <div class="clearfix"></div>
   <div class="col-sm-12 col-md-4">
      <div class="col-md-12">
         <div class="thumbnail">
            <?php
               if( $getReginfo['visitorPhoto'] != ""){
               	
               ?>
            <img src="<?php echo $getReginfo['visitorPhoto'] ;?>" id="blah"  class="img-thumbnail" 
               alt="<?php echo $getReginfo['visitorName'] ;?>">
            <?php
               }else{
               	
               ?>
            <img src="asset/manIcon.png" id="blah"  class="img-thumbnail" alt="Registar Visitor Photo">
            <?php
               }
               
               ?>
         </div>
      </div>
   </div>
   <div class="col-sm-12 col-md-8 text-left">
      <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
         <fieldset>
            <?php if(isset($updateRegInfo)){ echo $updateRegInfo; } ?>
            <div class="form-group row">
               <label for="1" class="col-sm-3 col-form-label text-left"><b>Visitor Name</b></label>
               <div class="col-sm-9">
                  <input type="hidden" name="id" value="<?php echo $getReginfo['id'] ;?>"/>
                  <input type="text" class="form-control" id="1" name="vName" 
                     value="<?php echo $getReginfo['visitorName'] ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="2" class="col-sm-3 col-form-label text-left"><b>Visitor Company</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="2" name="vCompany" value="<?php echo $getReginfo['visitorCompany'] ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="3" class="col-sm-3 col-form-label text-left"><b>Visitor Contact No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="3" name="vContact" value="<?php echo $getReginfo['visitorContactNo'] ;?>" >
               </div>
            </div>
            <div class="form-group row">
               <label for="4" class="col-sm-3 col-form-label text-left"><b>NID/Passport No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="4" name="vNid" value="<?php echo $getReginfo['visitorNidPassport'] ;?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="5" class="col-sm-3 col-form-label text-left"><b>Visitor Type</b></label>
               <div class="col-sm-9">
                  <select name="vType" class="form-control" id="5">
                     <?php 
                        if($vType){
                        	foreach($vType as $value){
                        	
                        		?>
                     <option <?php if($value['visitortype'] == $getReginfo['visitorType']){echo ' selected="selected"';}?> value="<?php echo $value['visitortype'] ;?>"><?php echo $value['visitortype'] ;?></option>
                     <?php }} ?>
                  </select>
               </div>
            </div>
            <div class="form-group row">
               <label for="7" class="col-sm-3 col-form-label text-left"><b>Visitor Picture</b></label>
               <div class="col-sm-9">
                  <input type="file" id="7" name="vPic" onchange="readURL(this);" >
               </div>
            </div>
            <div class="form-group row">
               <label for="inputPassword" class="col-sm-3 col-form-label text-left"><b></b></label>
               <div class="col-sm-9">
                  <button type="submit" name="update" class="btn btn-dark">Update</button>
                  <a href="registrationList.php" class="btn btn-secondary">View List</a>
               </div>
            </div>
         </fieldset>
      </form>
   </div>
</div>
<br/><br/>
<script type="text/javascript">
   function readURL(input) {
   	if (input.files && input.files[0]) {
   		var reader = new FileReader();
   
   		reader.onload = function (e) {
   			$('#blah')
   			.attr('src', e.target.result);
   		};
   
   		reader.readAsDataURL(input.files[0]);
   	}
   }
</script>
<?php include "inc/footer.php"; ?>