<?php
include "../lib/appSession.php";
Session ::checkappSession();
include "../config/config.php";
include "../lib/DB.php";
include "../lib/helpers.php";

$db       = new DataBase();


$appCrtId = Session :: get('empId');
$vName  = $_POST['vName'];
$select = "SELECT * FROM `tbl_registration` WHERE `visitorName` LIKE '%$vName%' 
		   and employeId = '$appCrtId' and deleted = '0'";
$sql    = $db->select($select);

if($sql){
	
	$data = "";
	$data = '<table class="table table-striped table-bordered" style="background:#eafdfa;width:100%;">';

	while($result = $sql->fetch_assoc()){
		
		$data .='<tr class="point">
					<td width="20%">'.$result['visitorName'].'</td>
					<td width="20%">'.$result['visitorContactNo'].'</td>
					<td width="20%">'.$result['visitorNidPassport'].'</td>
					<td width="20%">'.$result['visitorCompany'].'</td>
					<td width="20%">'.$result['visitorType'].'</td>
				</tr>';
		
	}
	echo $data;
	
}else{
	echo '<table class="table table-striped table-bordered" style="background:#eafdfa;">
	<tr>
		<td colspan="5" class="text-center">Data Not Found</td>
	</tr>
</table>';
}


?>
<style>
	.point{
		cursor: pointer;
	}
</style>



