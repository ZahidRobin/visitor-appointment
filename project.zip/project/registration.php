<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/registrationFunction.php";
   $regFunction = new Registration();
   
   if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['register'])){
   	$checkReg = $regFunction->appRegistaration($_POST,$_FILES);	
   }
   
   $vType = $regFunction->selectVtype();
   ?>
<br/><br/><br/>
<div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
   <h2 class="col-sm-12">Visitor Registration Profile</h2>
   <br/><br/><br/>
   <div class="clearfix"></div>
   <div class="col-sm-12 col-md-4">
      <div class="col-md-12">
         <div class="thumbnail">
            <img src="asset/manIcon.png" id="blah"  class="img-thumbnail" alt="Registar Visitor Photo">
         </div>
      </div>
   </div>
   <div class="col-sm-12 col-md-8 text-left">
      <form class="form-horizontal" method="post" method="post" enctype="multipart/form-data">
         <fieldset>
            <?php if(isset($checkReg)){ echo $checkReg; } ?>
            <div class="form-group row">
               <label for="1" class="col-sm-3 col-form-label text-left"><b>Visitor Name</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="1" name="vName" placeholder="Visitor Name" value="<?php if(isset($_POST['vName'])){echo $_POST['vName'] ;} ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="2" class="col-sm-3 col-form-label text-left"><b>Visitor Company</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="2" name="vCompany" placeholder="Visitor Company" value="<?php if(isset($_POST['vCompany'])){echo $_POST['vCompany'] ;} ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="3" class="col-sm-3 col-form-label text-left"><b>Visitor Contact No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="3" name="vContact" placeholder="Visitor Contact No" value="<?php if(isset($_POST['vContact'])){echo $_POST['vContact'] ;} ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="4" class="col-sm-3 col-form-label text-left"><b>NID/Passport No</b></label>
               <div class="col-sm-9">
                  <input type="text" class="form-control" id="4" name="vNid" placeholder="NID/Passport No" value="<?php if(isset($_POST['vNid'])){echo $_POST['vNid'] ;} ?>">
               </div>
            </div>
            <div class="form-group row">
               <label for="5" class="col-sm-3 col-form-label text-left"><b>Visitor Type</b></label>
               <div class="col-sm-9">
                  <select name="vType" class="form-control" id="5">
                     <option value="">- Select visitor Type -</option>
                     <?php 
                        if($vType){
                        	foreach($vType as $value){
                        	
                        		?>
                     <option  
                        <?php
                           if(isset($_POST['vType']) AND $_POST['vType'] 
                           == $value['visitortype']){
                           	echo 'selected="selected"';
                           }
                           ?> value="<?php echo $value['visitortype'] ;?>"><?php echo $value['visitortype'] ;?></option>
                     <?php }} ?>
                  </select>
               </div>
            </div>
            <div class="form-group row">
               <label for="7" class="col-sm-3 col-form-label text-left"><b>Visitor Picture</b></label>
               <div class="col-sm-9">
                  <input type="file" id="7" name="vPic" onchange="readURL(this);" >
               </div>
            </div>
            <div class="form-group row">
               <label for="inputPassword" class="col-sm-3 col-form-label text-left"><b></b></label>
               <div class="col-sm-9">
                  <button type="submit" name="register" class="btn btn-dark">Register</button>
                  <a href="registrationList.php" class="btn btn-secondary">View List</a>
               </div>
            </div>
         </fieldset>
      </form>
   </div>
</div>
<br/><br/>
<script type="text/javascript">
   function readURL(input) {
   	if (input.files && input.files[0]) {
   		var reader = new FileReader();
   
   		reader.onload = function (e) {
   			$('#blah')
   			.attr('src', e.target.result);
   		};
   
   		reader.readAsDataURL(input.files[0]);
   	}
   }
</script>
<?php include "inc/footer.php"; ?>