-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2018 at 03:11 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `visitorappointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL,
  `adminRegTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `adminName`, `adminEmail`, `adminPassword`, `adminRegTime`, `permission`) VALUES
(1, 'Pranto Abir', 'prantoabir1@gmail.com', 'ab7c17e73da4c5d72c44af8c954065c9', '2018-04-08 01:45:27', 4),
(2, 'Pranto Abir', 'prantoabir420@gmail.com', '37d9f2d6bc59341dc8f9214ff336399f', '2018-04-24 21:49:20', 1),
(3, 'MR.Pranto', 'prantoabir490@gmail.com', '37d9f2d6bc59341dc8f9214ff336399f', '2018-04-24 21:51:12', 3),
(4, 'Sharmin Akter', 'sharmin721381@gmail.com', 'ae320a255dceb31bbf96ba1a4e96047f', '2018-04-26 15:53:52', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointment`
--

CREATE TABLE `tbl_appointment` (
  `id` int(11) NOT NULL,
  `visitorName` varchar(255) NOT NULL,
  `visitorCompany` varchar(200) NOT NULL,
  `visitorType` varchar(200) NOT NULL,
  `visitorNID` varchar(50) NOT NULL,
  `visitorReg_phoneNum` varchar(50) NOT NULL,
  `visitingDate` date NOT NULL,
  `appointmentWith` varchar(200) NOT NULL,
  `appointmentCRTtime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `appointmrntCreator` varchar(200) NOT NULL,
  `vcleDriverNmae` varchar(200) NOT NULL,
  `vcleNo` varchar(50) NOT NULL,
  `parkingLocation` varchar(255) NOT NULL,
  `visitorGroupMember` text NOT NULL,
  `checkIn` varchar(10) NOT NULL,
  `checkInTime` time NOT NULL,
  `printHowMuch` int(11) NOT NULL,
  `mettingStart` varchar(10) NOT NULL,
  `meeting_start_time` time NOT NULL,
  `checkOut` varchar(10) NOT NULL,
  `checkOutTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_companyinfo`
--

CREATE TABLE `tbl_companyinfo` (
  `id` int(11) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `addedTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_companyinfo`
--

INSERT INTO `tbl_companyinfo` (`id`, `companyName`, `address`, `addedTime`) VALUES
(1, 'Smart Corporation', 'Eastern Plaza, Hatirapol, Dhaka', '2018-04-08 01:58:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employe`
--

CREATE TABLE `tbl_employe` (
  `id` int(11) NOT NULL,
  `employName` varchar(200) NOT NULL,
  `employId` varchar(200) NOT NULL,
  `addedTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_employe`
--

INSERT INTO `tbl_employe` (`id`, `employName`, `employId`, `addedTime`) VALUES
(1, 'Pranto', 'smc-0011', '2018-04-08 01:33:59'),
(2, 'sharmin', 'smc-0012', '2018-04-08 01:34:57'),
(3, 'Kazol', 'smc-0013', '2018-04-08 01:38:18'),
(6, 'Rifat', 'smc-0014', '2018-04-10 23:00:06'),
(7, 'Ashik', 'smc-0015', '2018-04-10 23:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `id` int(11) NOT NULL,
  `visitorName` varchar(200) NOT NULL,
  `visitorCompany` varchar(200) NOT NULL,
  `visitorContactNo` varchar(50) NOT NULL,
  `visitorNidPassport` varchar(50) NOT NULL,
  `visitorType` varchar(50) NOT NULL,
  `visitorPhoto` varchar(200) NOT NULL,
  `employeId` varchar(100) NOT NULL,
  `deleted` int(11) NOT NULL,
  `regTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`id`, `visitorName`, `visitorCompany`, `visitorContactNo`, `visitorNidPassport`, `visitorType`, `visitorPhoto`, `employeId`, `deleted`, `regTime`) VALUES
(14, 'Sharmin Akter', 'DUET', '01784485212', '19965016325000143', 'Personal', 'vImge/5122a81347.jpg', 'smc-0011', 1, '2018-04-18 00:10:38'),
(15, 'M.R Pranto', 'Smart Corporation', '01710750665', '19974417183000289', 'Interviewer', 'vImge/22b50ad408.jpg', 'smc-0011', 0, '2018-04-18 18:29:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visitortype`
--

CREATE TABLE `tbl_visitortype` (
  `id` int(11) NOT NULL,
  `visitortype` varchar(200) NOT NULL,
  `addedTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_visitortype`
--

INSERT INTO `tbl_visitortype` (`id`, `visitortype`, `addedTime`) VALUES
(2, 'Customar', '2018-04-08 01:53:49'),
(3, 'Personal', '2018-04-08 16:05:50'),
(4, 'Supplier', '2018-04-10 16:30:30'),
(5, 'Auditor', '2018-04-10 17:10:02'),
(6, 'Interviewer', '2018-04-11 12:51:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_companyinfo`
--
ALTER TABLE `tbl_companyinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_employe`
--
ALTER TABLE `tbl_employe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_visitortype`
--
ALTER TABLE `tbl_visitortype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_companyinfo`
--
ALTER TABLE `tbl_companyinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_employe`
--
ALTER TABLE `tbl_employe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_visitortype`
--
ALTER TABLE `tbl_visitortype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
