<?php

class DataBase{
	
	public $host   = DB_HOST;
	public $user   = DB_USER;
	public $pass   = DB_PASS;
	public $dbName = DB_NAME;
	
	public $link;
	public $error;
	
	
	public function __construct(){
		
		$this->connectDB();
		
	}

	private function connectDB(){
		
		$this->link  = 	new mysqli($this->host,$this->user,$this->pass,$this->dbName);
	
		if(!$this->link){
		
			$this->error = "Connection Fail".$this->link->connect_error;
			return FALSE;
		
		}

		
	}
	
	//Select Option
	
	public function select($select){

		$result = $this->link->query($select) or die($this->link->error . __LINE__);
		if($result->num_rows > 0){
			
			return $result;
			
		} else{

			return false;
		}

	}
    
	//Insart Option
    
	public function insart($ins){

		$insart_row = $this->link->query($ins) or die($this->link->error.__LINE__);
		if($insart_row){
        	
			return $insart_row;
        	
		}else{

			return FALSE;
		}

	}
	
	//multi Option
    
	public function multi($mult){

		$multiQuery = $this->link->multi_query($mult) or die($this->link->error.__LINE__);
		if($multiQuery){
        	
			return $multiQuery;
        	
		}else{

			return FALSE;
		}

	}
	
	//update option
	
	
	public function update($update){
		
		$update_row = $this->link->query($update) or die($this->link->error.__LINE__);
		if($update_row){
        	
			return $update_row;
        	
		}else{

			return FALSE;
		}

		
	}
	
	
	public function delete($delete){
		
		$delete_row = $this->link->query($delete) or die($this->link->error.__LINE__);
		if($delete_row){
        	
			return $delete_row;
        	
		}else{

			return FALSE;
		}

		
	}
	
/*	public function lastId($lastId){
		
		$lstId = $this->link->query($lastId) or die($this->link->error.__LINE__);
		if($lstId->insert_id > 0){
        	
			return $lstId;
        	
		}else{

			return FALSE;
		}

		
	}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}