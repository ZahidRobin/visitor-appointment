<?php include "inc/header.php"; ?>
<?php include "inc/navbar.php"; ?>
<?php
   include "php/classes/appointmentFunction.php";
   include "php/classes/registrationFunction.php";
   $regFunction = new Registration();
   $appFunction = new appointmentFunctiuon();
      
   $appList = $appFunction->appointmentList();
   $vType   = $regFunction->selectVtype();
   ?>
<br/><br/>
<div class="row" style="border-radius:4px; margin-top: 20px; padding: 20px;">
   <h2 class="col-sm-12"><b><i class="fas fa-th"></i> Smart Corporation</b></h2>
   <h4 class="col-sm-12">Visitor Appointment List</h4>
   <br/><br/><br/>
   <div class="col-md-4">
      <form action="" method="post">
         <div class="input-group">
            <input type="text" class="form-control" value="<?php if(isset($_POST['appId'])){echo $_POST['appId'];}?>" name="appId" placeholder="Search By Id"/>
            <div class="input-group-append">
               <button class="btn btn-dark" type="submit" name="searchById">
               <i class="fas fa-search"></i>
               </button>
            </div>
         </div>
      </form>
   </div>
   <div class="col-md-4"></div>
   <div class="col-md-4">
      <form action="" method="post">
         <div class="input-group">
            <select name="vStype" class="form-control" id="5">
               <option>- Search By visitor Type -</option>
               <?php 
                  if($vType){
                  	foreach($vType as $value){
                               			
                  		?>
               <option
                  <?php
                     if(isset($_POST['vStype']) AND $_POST['vStype'] == $value['visitortype']){
                     	
                     	echo 'selected="selected"';
                     	
                     }
                     
                     ?>
                  value="<?php echo $value['visitortype'] ;?>">
                  <?php echo $value['visitortype'] ;?>
               </option>
               <?php }} ?>
            </select>
            <div class="input-group-append">
               <button class="btn btn-dark" type="submit" name="searchType">
               <i class="fas fa-search"></i>
               </button>
            </div>
         </div>
      </form>
   </div>
   <br/><br/><br/>
   <div class="col-sm-12 col-md-12" style="border: 1px solid #343A40; border-radius:4px; padding: 20px;">
      <div class="table-responsive">
         <?php
            $loginMsg = Session :: get('loginMsg');
            if(isset($loginMsg)){
            	echo $loginMsg;
            }
            Session :: set('loginMsg',NULL);
            ?>
         <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
               <tr>
                  <th title="Serial No">Sl</th>
                  <th title="Visitor Imge">Imge</th>
                  <th title="Visitor appointment Id">AppID</th>
                  <th title="Visitor Name">Name</th>
                  <th title="Visitor Type">Type</th>
                  <th title="Metting With">Metting</th>
                  <th title="Visitor Contact">Contact</th>
                  <th title="Visitor Date">Visiting Date</th>
                  <th width="20%">Control</th>
               </tr>
            </thead>
            <tbody>
               <?php
                  if($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['searchType'])){
                               
                  	$vSearchType = $_POST['vStype'];
                  	$searchType  = $appFunction->searchByType($vSearchType);
                               
                  	$i = 0;
                  	if($searchType){
                               
                  		foreach($searchType as $value){
                  			$i++;
                               
                  			?>
               <tr>
                  <td><?php echo $i ;?></td>
                  <td>
                     <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconBg.png'); width: 40px;height: 40px;
                        border-radius: 5px;"/>
                  </td>
                  <td><?php echo $value['id'];?></td>
                  <td><?php echo $value['visitorName'];?></td>
                  <td><?php echo $value['visitorType'];?></td>
                  <td><?php echo $value['appointmentWith'];?></td>
                  <td><?php echo $value['visitorReg_phoneNum'];?></td>
                  <td><?php echo $help->Formate($value['visitingDate']);?></td>
                  <td>
                     <a href="" class="btn btn-dark btn-sm" title="View visitor details" 
                        data-toggle="modal" data-target=".v<?php echo $value['id'];?>">
                     <i class="fas fa-eye"></i>
                     </a>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="visitorCheckinInfo.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check in">
                     <i class="fas fa-hand-point-left"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] < 2){
                        	?>
                     <a target="_blank" href="pdf/visitorCard.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Print visitor card">
                     <i class="fas fa-print"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] > 0 AND $value['mettingStart'] == ''){
                        	?>
                     <a href="meetStart.php?meeting=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Metting Start">
                     <i class="fas fa-comments"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="updateApp.php?id=<?php echo $value['id'];?>" 
                        class="btn btn-dark btn-sm" title="Edit visitor appointment">
                     <i class="fas fa-pen-square"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != ""){
                        	?>
                     <a href="checkOut.php?checkOut=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check out">
                     <i class="fas fa-hand-point-right"></i>
                     </a>
                     <?php
                        }
                        ?>
                  </td>
                  <div class="modal fade v<?php echo $value['id'];?>">
                     <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title text-center" id="exampleModalLabel"></h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
                                    <h2 class="col-sm-12">Visitor Details</h2>
                                    <br/><br/><br/>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 col-md-12 text-left">
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
                                          <div class="col-sm-9">
                                             <div class="thumbnail col-sm-8">
                                                <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconView.jpg') !important; width: 200px; height: 200px;" class="img-thumbnail" >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-4 col-form-label text-left"><b>Visitor Name</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorName'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="2" class="col-sm-4 col-form-label text-left"><b>Visitor Company</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorCompany'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="3" class="col-sm-4 col-form-label text-left"><b>Visitor Contact No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorReg_phoneNum'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="4" class="col-sm-4 col-form-label text-left"><b>NID/Passport No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorNID'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visitor Type</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorType'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Metting With</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['appointmentWith'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visiting Date</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $help->Formate($value['visitingDate']);?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check IN</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php 
                                                if( $value['checkIn'] == ""){
                                                	echo "NO";
                                                }else{
                                                	echo "YES";
                                                }
                                                ?>
                                             </label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </tr>
               <?php }}}elseif($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_POST['searchById'])){
                  $appId      = $_POST['appId'];
                  $searchById = $appFunction->searchById($appId);
                           			
                           			$i = 0;
                  if($searchById){
                     	
                  	foreach($searchById as $value){
                  		$i++;
                  		
                  ?>
               <tr>
                  <td><?php echo $i ;?></td>
                  <td>
                     <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconBg.png'); width: 40px;height: 40px;
                        border-radius: 5px;"/>
                  </td>
                  <td><?php echo $value['id'];?></td>
                  <td><?php echo $value['visitorName'];?></td>
                  <td><?php echo $value['visitorType'];?></td>
                  <td><?php echo $value['appointmentWith'];?></td>
                  <td><?php echo $value['visitorReg_phoneNum'];?></td>
                  <td><?php echo $help->Formate($value['visitingDate']);?></td>
                  <td>
                     <a href="" class="btn btn-dark btn-sm" title="View visitor details" 
                        data-toggle="modal" data-target=".v<?php echo $value['id'];?>">
                     <i class="fas fa-eye"></i>
                     </a>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="visitorCheckinInfo.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check in">
                     <i class="fas fa-hand-point-left"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] < 2){
                        	?>
                     <a target="_blank" href="pdf/visitorCard.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Print visitor card">
                     <i class="fas fa-print"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] > 0 AND $value['mettingStart'] == ''){
                        	?>
                     <a href="meetStart.php?meeting=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Metting Start">
                     <i class="fas fa-comments"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="updateApp.php?id=<?php echo $value['id'];?>" 
                        class="btn btn-dark btn-sm" title="Edit visitor appointment">
                     <i class="fas fa-pen-square"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != ""){
                        	?>
                     <a href="checkOut.php?checkOut=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check out">
                     <i class="fas fa-hand-point-right"></i>
                     </a>
                     <?php
                        }
                        ?>
                  </td>
                  <div class="modal fade v<?php echo $value['id'];?>">
                     <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title text-center" id="exampleModalLabel"></h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
                                    <h2 class="col-sm-12">Visitor Details</h2>
                                    <br/><br/><br/>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 col-md-12 text-left">
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
                                          <div class="col-sm-9">
                                             <div class="thumbnail col-sm-8">
                                                <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconView.jpg') !important; width: 200px; height: 200px;" class="img-thumbnail" >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-4 col-form-label text-left"><b>Visitor Name</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorName'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="2" class="col-sm-4 col-form-label text-left"><b>Visitor Company</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorCompany'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="3" class="col-sm-4 col-form-label text-left"><b>Visitor Contact No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorReg_phoneNum'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="4" class="col-sm-4 col-form-label text-left"><b>NID/Passport No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorNID'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visitor Type</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorType'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Metting With</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['appointmentWith'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visiting Date</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $help->Formate($value['visitingDate']);?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check IN</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php 
                                                if( $value['checkIn'] == ""){
                                                	echo "NO";
                                                }else{
                                                	echo "YES";
                                                }
                                                ?>
                                             </label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </tr>
               <?php }}}else{ ?>
               <?php
                  $i = 0;
                  if($appList){
                  	foreach($appList as $value){
                  		$i++;
                              
                  		?>
               <tr>
                  <td><?php echo $i ;?></td>
                  <td>
                     <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconBg.png'); width: 40px;height: 40px;
                        border-radius: 5px;"/>
                  </td>
                  <td><?php echo $value['id'];?></td>
                  <td><?php echo $value['visitorName'];?></td>
                  <td><?php echo $value['visitorType'];?></td>
                  <td><?php echo $value['appointmentWith'];?></td>
                  <td><?php echo $value['visitorReg_phoneNum'];?></td>
                  <td><?php echo $help->Formate($value['visitingDate']);?></td>
                  <td>
                     <a href="" class="btn btn-dark btn-sm" title="View visitor details" 
                        data-toggle="modal" data-target=".v<?php echo $value['id'];?>">
                     <i class="fas fa-eye"></i>
                     </a>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="visitorCheckinInfo.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check in">
                     <i class="fas fa-hand-point-left"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] < 2){
                        	?>
                     <a href="pdf/visitorCard.php?id=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Print visitor card">
                     <i class="fas fa-print"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != "" AND $value['printHowMuch'] > 0 AND $value['mettingStart'] == ''){
                        	?>
                     <a href="meetStart.php?meeting=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Metting Start">
                     <i class="fas fa-comments"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] == ""){
                        	?>
                     <a href="updateApp.php?id=<?php echo $value['id'];?>" 
                        class="btn btn-dark btn-sm" title="Edit visitor appointment">
                     <i class="fas fa-pen-square"></i>
                     </a>
                     <?php
                        }
                        ?>
                     <?php
                        if($value['checkIn'] != ""){
                        	?>
                     <a href="checkOut.php?checkOut=<?php echo $value['id'];?>" class="btn btn-dark btn-sm" title="Check out">
                     <i class="fas fa-hand-point-right"></i>
                     </a>
                     <?php
                        }
                        ?>
                  </td>
                  <div class="modal fade v<?php echo $value['id'];?>">
                     <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title text-center" id="exampleModalLabel"></h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="row" style="border: 1px solid #343A40; border-radius:4px; margin: 20px; padding: 20px;">
                                    <h2 class="col-sm-12">Visitor Details</h2>
                                    <br/><br/><br/>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 col-md-12 text-left">
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-3 col-form-label text-left"><b></b></label>
                                          <div class="col-sm-9">
                                             <div class="thumbnail col-sm-8">
                                                <img src="captureImge/<?php echo $value['id'];?>.jpg" style="background: url('asset/manIconView.jpg') !important; width: 200px; height: 200px;" class="img-thumbnail" >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="1" class="col-sm-4 col-form-label text-left"><b>Visitor Name</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorName'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="2" class="col-sm-4 col-form-label text-left"><b>Visitor Company</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorCompany'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="3" class="col-sm-4 col-form-label text-left"><b>Visitor Contact No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorReg_phoneNum'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="4" class="col-sm-4 col-form-label text-left"><b>NID/Passport No</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorNID'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visitor Type</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['visitorType'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Metting With</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $value['appointmentWith'];?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Visiting Date</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left"><?php echo $help->Formate($value['visitingDate']);?></label>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="5" class="col-sm-4 col-form-label text-left"><b>Check IN</b></label>
                                          <div class="col-sm-8">
                                             <label for="1" class="col-form-label text-left">
                                             <?php 
                                                if( $value['checkIn'] == ""){
                                                	echo "NO";
                                                }else{
                                                	echo "YES";
                                                }
                                                ?>
                                             </label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </tr>
               <?php }} ?>
               <?php } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<br/><br/><br/>
<?php include "inc/footer.php"; ?>