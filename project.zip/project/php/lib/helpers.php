<?php

class Helpers {
	
	public function validation($data){
		
		$data = trim($data);
		$data = stripcslashes($data);
		$data = htmlspecialchars($data);
		return $data;
		
	}
	
	public function Formate($date){
		
	return date('F j, Y',strtotime($date));
	
	}
	
	public function Formate_2($date){
		
	return date('F j, Y, g:i a',strtotime($date));
	
	}
	
	
	public function title(){
		
		
		
		$path  = $_SERVER['SCRIPT_FILENAME'];
		$title = basename($path,".php");
		$title = str_replace('_',' ',$title);
		
		if($title == 'index'){
			
			$title = "Home";
			
		}else if($title == "createAppointment"){
			
		 	$title = "Create Appointment";
		 	
		 }else if($title == "registration"){
			
		 	$title = " Registration";
		 	
		 }else if($title == "registrationList"){
			
		 	$title = " Registration List";
		 	
		 }else if($title == "visitorCheckinInfo"){
			
		 	$title = " Visitor CheckIn Info ";
		 	
		 }else if($title == "visitorList"){
			
		 	$title = " Visitor List";
		 	
		 }

		 return $title = ucfirst($title);
		
	}
	
	
	public function title_admin(){
		
		
		
		$path  = $_SERVER['SCRIPT_FILENAME'];
		$title = basename($path,".php");
		$title = str_replace('_',' ',$title);
		
		if($title == 'index'){
			
			$title = "Dashboard";
			
		}elseif($title == 'addEmploy'){
			
			$title = "Add Employe";
			
		}elseif($title == 'addVisitorType'){
			
			$title = "Add Visitor Type";
			
		}elseif($title == 'changePassword'){
			
			$title = "Change Password";
			
		}elseif($title == 'deletedVisitor'){
			
			$title = "Deleted Visitor List";
			
		}elseif($title == 'employList'){
			
			$title = "Employe List";
			
		}elseif($title == 'setting'){
			
			$title = "Setting";
			
		}elseif($title == 'visitorDetails'){
			
			$title = "Visitor Details";
			
		}elseif($title == 'visitorReport'){
			
			$title = "Visitor Report List";
			
		}elseif($title == 'visitorType'){
			
			$title = "Visitor Type List";
			
		}elseif($title == 'nVisitedVDetails'){
			
			$title = "Not Visited Visitor";
			
		}elseif($title == 'regVisitor'){
			
			$title = "Registration Visitor";
			
		}elseif($title == 'visitedVDetails'){
			
			$title = "Visited Visitor";
			
		}

		 return $title = ucfirst($title);
		
	}
	
	

	
	public function UcCase($data){
		
		$data = ucfirst($data);
		return $data;
		
	}
	
	
	
	 public function convert_number_to_words($number)
    {
        $hyphen = '-';
        $conjunction = ' And ';
        $separator = ' ';
        $negative = 'Negative ';
        $decimal = ' Point ';
        $dictionary = array(
            0 => 'Zero',
            1 => 'One',
            2 => 'Two',
            3 => 'Three',
            4 => 'Four',
            5 => 'Five',
            6 => 'Six',
            7 => 'Seven',
            8 => 'Eight',
            9 => 'Eine',
            10 => 'Ten',
            11 => 'Eleven',
            12 => 'Twelve',
            13 => 'Thirteen',
            14 => 'Fourteen',
            15 => 'Fifteen',
            16 => 'Sixteen',
            17 => 'Seventeen',
            18 => 'Eighteen',
            19 => 'Nineteen',
            20 => 'Twenty',
            30 => 'Thirty',
            40 => 'Forty',
            50 => 'Fifty',
            60 => 'Sixty',
            70 => 'Seventy',
            80 => 'Eighty',
            90 => 'Ninety',
            100 => 'Hundred',
            1000 => 'Thousand',
            1000000 => 'Million',
            1000000000 => 'Billion',
            1000000000000 => 'Trillion',
            1000000000000000 => 'Quadrillion',
            1000000000000000000 => 'Quintillion'
        );

        if (!is_numeric($number)) {
            return false;
        }

        if (($number >= 0 && (int)$number < 0) || (int)$number < 0 - PHP_INT_MAX) {
            // overflow
            trigger_error(
                '$this -> convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
                E_USER_WARNING
            );
            return false;
        }

        if ($number < 0) {
            return $negative . $this->convert_number_to_words(abs($number));
        }

        $string = $fraction = null;

        if (strpos($number, '.') !== false) {
            list($number, $fraction) = explode('.', $number);
        }

        switch (true) {
            case $number < 21:
                $string = $dictionary[$number];
                break;
            case $number < 100:
                $tens = ((int)($number / 10)) * 10;
                $units = $number % 10;
                $string = $dictionary[$tens];
                if ($units) {
                    $string .= $hyphen . $dictionary[$units];
                }
                break;
            case $number < 1000:
                $hundreds = $number / 100;
                $remainder = $number % 100;
                $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
                if ($remainder) {
                    $string .= $conjunction . $this->convert_number_to_words($remainder);
                }
                break;
            default:
                $baseUnit = pow(1000, floor(log($number, 1000)));
                $numBaseUnits = (int)($number / $baseUnit);
                $remainder = $number % $baseUnit;
                $string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
                if ($remainder) {
                    $string .= $remainder < 100 ? $conjunction : $separator;
                    $string .= $this->convert_number_to_words($remainder);
                }
                break;
        }

        if (null !== $fraction && is_numeric($fraction)) {
            $string .= $decimal;
            $words = array();
            foreach (str_split((string)$fraction) as $number) {
                $words[] = $dictionary[$number];
            }
            $string .= implode(' ', $words);
        }

        return $string;
    }
	
	
	
	
	
	
	
}


?>